from flask import Flask, render_template, request, session, redirect, url_for, jsonify
import requests
from pymongo import MongoClient
import os
import uuid


app = Flask(__name__, template_folder="templates")

# create a MongoClient instance
client = MongoClient('mongodb://zohayb:password123@104.236.192.183:27017/flask_db')
db = client.flask_db
collection = db.location_data

@app.route("/")
def index():
    return render_template("home1.html")


@app.route('/location', methods=['POST'])
def store_location():

    # Get the location data from the request
    data = request.get_json()
    vehicle_id = data['vehicle_id']
    eta = data['eta']
    geo_lat = data['geo_lat']
    geo_long = data['geo_long']
    route = data['route']
    on_route = data['on_route']
    status = data['status']

    # Insert the location data into the collection. If primary key exists, update the row.
    query = {'vehicle_id': vehicle_id}
    update = {'$set': {'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long,
                       'route': route, 'on_route': on_route, 'status': status}}
    collection.update_one(query, update, upsert=True)

    return jsonify({'message': 'Location data stored successfully!'})

# Endpoint to retrieve find the first available vehicle


@app.route('/vehicle', methods=['GET'])
def find_available_vehicle():
    try:
        # Retrieve the first available vehicle from the collection
        query = {'status': 'available'}
        sort = [('eta', 1)]
        vehicle_data = collection.find_one(query, sort=sort)
        if vehicle_data is None:
            return jsonify({'error': 'No available vehicles found.'}), 404

        # Return vehicle id to demand side
        vehicle_id = vehicle_data['vehicle_id']
        eta = vehicle_data['eta']
        geo_lat = vehicle_data['geo_lat']
        geo_long = vehicle_data['geo_long']
        route = vehicle_data['route']
        on_route = vehicle_data['on_route']
        status = vehicle_data['status']

        return jsonify({'vehicle_id': vehicle_id, 'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long, 'route': route, 'on_route': on_route, 'status': status})
    except:
        return jsonify({'error': 'Failed to get vehicle in DB data.'}), 500


@app.route('/request_data', methods=['GET', 'POST'])
def request_data():

    data = request.get_json()
    order_id = data['order_id']
    status = "unavailable"
    # Extract the vehicle data from the response
    vehicle_id = data['vehicle_id']
    dropoff = data['dropoff_location']
    pickup = data['pickup_location']
    eta = data['eta']
    geo_location = {
        # Extract 'lat' from nested dictionary
        'lat': data['geo_location']['lat'],
        # Extract 'long' from nested dictionary
        'long': data['geo_location']['long']
    }
    route = data['route']
    on_route = data['on_route']

    # Update MongoDB with the order_id and status
    collection.update_one({'vehicle_id': vehicle_id},
                          {'$set': {'order_id': order_id, 'status': status, 'dropoff_location': dropoff, 'destination_location': pickup}})

    # Return the updated vehicle data
    return jsonify({
        'vehicle_id': vehicle_id,
        'eta': eta,
        'geo_location': geo_location,
        'route': route,
        'on_route': on_route,
        'order_id': order_id,
        'status': status
    })


# Endpoint to reset vehicle data
@app.route('/vehicle/reset/<vehicle_id>', methods=['POST'])
def reset_vehicle_data(vehicle_id):
    # Reset the vehicle data in the collection
    query = {'vehicle_id': int(vehicle_id)}
    update = {'$set': {'route': '', 'on_route': False, 'order_id': '', 'status': 'available', 'destination_location': ''}}
    collection.update_one(query, update)

    return jsonify({'message': 'Vehicle data reset successfully!'})

# Heartbeat endpoint to receive the latest location data from the autonomous vehicle
@app.route('/heartbeat', methods=['GET','POST'])
def heartbeat():
    global latest_location_data
    data = request.get_json()
    latest_location_data = {
        'vehicle_id': data['vehicle_id'],
        'eta': data['eta'],
        'geo_lat': data['geo_lat'],
        'geo_long': data['geo_long'],
        'route': data['route'],
        'on_route': data['on_route'],
        'status': data['status']
    }

    requests.post('https://swesupply2023team21.xyz/location', json=latest_location_data)
    print("Heartbeat recieved")
    return jsonify({'message': 'Heartbeat recieved'})

# Location endpoint to retrieve the latest location data from the backend
@app.route('/location', methods=['GET', 'POST'])
def location():
    global latest_location_data
    if request.method == 'GET':
        return jsonify(latest_location_data)
    elif request.method == 'POST':
        data = request.get_json()
        # Save the new location data to the database
        # ...

        return jsonify({'message': 'Location data saved to DB'})


@app.route('/request_vehicle')
def render_webpage():
    # Render the webpage with the form for user input
    return render_template('vehicle_request.html')

@app.route('/request', methods=['POST'])
def handle_request():
    # Get destination location and pickup location from the form data
    json_data = request.get_json()
    dropoff_location = json_data.get('dropoff_location')
    pickup_location = json_data.get('pickup_location')
    order_id = json_data.get('order_id')

    # Check if destination_location and pickup_location are provided
    if not dropoff_location or not pickup_location:
        return jsonify({'error': 'Both destination_location and pickup_location are required.'}), 400

    try:
        vehicle_request = requests.get('https://swesupply2023team21.xyz/vehicle')
        
        vehicle_data = vehicle_request.json()
        vehicle_request_JSON = {
            'vehicle_id': vehicle_data['vehicle_id'],
            'eta': vehicle_data['eta'],
            'geo_location': {
                'lat': vehicle_data['geo_lat'],
                'long': vehicle_data['geo_long']
            },
            'route': vehicle_data['route'],
            'on_route': vehicle_data['on_route'],
            'dropoff_location': dropoff_location,
            'pickup_location': pickup_location,
            'order_id': order_id # Generate a random order ID
        }

        try:
            requests.post('https://swesupply2023team21.xyz/request_data', json=vehicle_request_JSON)
            # requests.post('http://localhost:5002/dispatch', json=vehicle_request_JSON)

            return jsonify(vehicle_request_JSON)
        except:
            return jsonify({'error': 'Failed to get request data.'}), 500
    except:
        return jsonify({'error': 'Failed to get vehicle data.'}), 500


if __name__ == "__main__":
    app.run(host='0.0.0.0')
