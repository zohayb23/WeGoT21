import unittest
from pymongo.errors import DuplicateKeyError
from recording import Recording

class RecordingTestCase(unittest.TestCase):

    def setUp(self):
        self.recording = Recording()

    def tearDown(self):
        self.recording.recording_collection.delete_many({"desc": "Test recording"})

    def test_createRecording(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        result = self.recording.createRecording(recordingID, desc, URL, vehicleID)
        self.assertTrue(result)

    def test_setRecordingsDesc(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        new_desc = 'New test recording'
        result = self.recording.setRecordingsDesc(recordingID, new_desc)
        self.assertTrue(result)

    def test_getRecordingsDesc(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        result = self.recording.getRecordingsDesc(recordingID)
        self.assertEqual(result, desc)

    def test_setRecordingsUrl(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        new_URL = 'https://test.com/newrecording.mp4'
        result = self.recording.setRecordingsUrl(recordingID, new_URL)
        self.assertTrue(result)

    def test_getRecordingsUrl(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        result = self.recording.getRecordingsUrl(recordingID)
        self.assertEqual(result, URL)

    def test_setRecordingsVehicleRef(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        new_vehicleID = '456'
        result = self.recording.setRecordingsVehicleRef(recordingID, new_vehicleID)
        self.assertTrue(result)

    def test_getRecordingsFromVehicleRef(self):
        recordingID = self.recording.getLatestRecordingID()
        desc = 'Test recording'
        URL = 'https://test.com/recording.mp4'
        vehicleID = '123'
        self.recording.createRecording(recordingID, desc, URL, vehicleID)
        result = self.recording.getRecordingsFromVehicleRef(vehicleID)
        self.assertIsNotNone(result)

if __name__ == '__main__':
    unittest.main()
