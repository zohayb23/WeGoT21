from flask import Flask, jsonify, request, session, redirect, url_for, render_template, flash
import bcrypt
from pymongo import MongoClient
from manager.manager import Manager
from fleet.fleet import Fleet
from vehicle.vehicle import Vehicle
from flag.flag import Flag

# Create instances of the Manager and Fleet classes
manager = Manager()
fleet = Fleet()
vehicle = Vehicle()
flag = Flag()

# Create a Flask app instance
app = Flask(__name__)

# Create a secret key for the session
app.secret_key = "SUPERSECRETKEYSHUSH"

# Set up the MongoDB client
client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')

# Route for the login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get the username and password from the request form
        username = request.form['username']
        password = request.form['password']

        # Check if the user is authorized to log in
        if manager.loginUser(username, password):
            # Set session information
            session['managerID'] = str(manager.getUser(username)['managerID'])
            session['managerName'] = str(manager.getUser(username)['managerName'])
            session.permanent = True

            # Redirect to the dashboard
            return redirect(url_for('dashboard'))
        else:
            # Display an error message
            flash('Invalid username or password', 'error')
            return redirect(url_for('login'))
    else:
        # Display the login page
        return render_template('login.html')

# Route for the logout page
@app.route('/logout')
def logout():
    # Remove session information
    session.pop('managerID', None)
    session.pop('managerName', None)

    # Redirect to the login page
    return redirect(url_for('login'))

# Route for the account page
@app.route('/account', methods=['GET', 'POST'])
def account():
    managerID = int(session.get('managerID'))

    if request.method == 'POST':
        # Retrieve the updated user information from the form
        username = request.form['username']
        name = request.form['name']
        email = request.form['email']
        phonenumber = int(request.form['phonenumber'])  # Convert to integer

        if 'username-submit' in request.form:
            manager.setUsername(managerID, username)
            flash('Username updated successfully')

        elif 'name-submit' in request.form:
            # Update the user's name in MongoDB
            manager.setManagerName(managerID, name)
            flash('Name updated successfully')

        elif 'email-submit' in request.form:
            # Update the user's email in MongoDB
            manager.setManagerEmail(managerID, email)
            flash('Email updated successfully')

        elif 'phonenumber-submit' in request.form:
            # Update the user's phone number in MongoDB
            manager.setManagerPhonenumber(managerID, phonenumber)
            flash('Phone number updated successfully')

        elif 'password-submit' in request.form:
            # Update the user's password in MongoDB
            old_password = request.form['old_password']
            new_password = request.form['new_password']
            confirm_password = request.form['confirm_password']

            # Check if the old password entered matches the one in the database
            old_hashed_password = manager.getManagerPassword(managerID)
            old_password = old_password.encode('utf-8')
            if isinstance(old_password, str):
                old_password = old_password.encode('utf-8')

            if isinstance(old_hashed_password, str):
                old_hashed_password = old_hashed_password.encode('utf-8')

            if not bcrypt.checkpw(old_password, old_hashed_password):
                flash('Incorrect old password')
                return redirect(url_for('account'))

            # Check if the new password and confirmation match
            if new_password != confirm_password:
                flash('New password and confirmation do not match')
                return redirect(url_for('account'))

            # Hash the new password and update it in the database
            manager.resetPassword(managerID, new_password)
            flash('Password updated successfully')


        # Redirect the user back to the account page
        return redirect(url_for('account'))

    else:
        # Fetch the user's data from MongoDB
        username = manager.getManagerUsername(managerID)
        name = manager.getManagerName(managerID)
        email = manager.getManagerEmail(managerID)
        phonenumber = manager.getManagerPhonenumber(managerID)

        # Render the account page with the user's data
        return render_template('account.html', username=username, name=name, email=email, phonenumber=phonenumber)

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'managerID' not in session:
        return redirect(url_for('login'))

    # Fetch all fleets
    fleets = manager.getManagerFleets(int(session['managerID']))

    if request.method == 'GET':
        # Render the fleet_dashboard.html template with the fleets data
        return render_template('dashboard.html', fleets=fleets)

@app.route('/dashboard/edit_fleet/<int:fleetID>', methods=['GET', 'POST'])
def edit_fleet(fleetID):
    if 'managerID' not in session:
        return redirect(url_for('dashboard'))

    # Fetch the fleet to edit from the database
    fleet_to_edit = fleet.getFleetByID(fleetID)
    fleetID = fleet_to_edit['fleetID']

    if request.method == 'POST':
        # Get the updated data from the form
        desc = request.form.get('desc')
        capacity = int(request.form.get('capacity'))
        availability = int(request.form.get('availability'))
        status = request.form.get('status')
        plugin = request.form.get('plugin')

        # If capacity is changed to a number lower than the current or new availability,
        # set availability to the same value and availability should never go higher than capacity
        if capacity < fleet_to_edit['fleetAvailability'] or capacity < availability:
            availability = capacity

        # Update the fleet with the new data
        fleet.setFleetDesc(fleetID, desc)
        fleet.setFleetCapacity(fleetID, capacity)
        fleet.setFleetAvailability(fleetID, availability)
        fleet.setFleetStatus(fleetID, status)
        fleet.setFleetPlugin(fleetID, plugin)

        flash('Fleet updated successfully!', 'success')
        return redirect(url_for('dashboard'))

    # Display the fleet information and edit form
    return render_template('edit_fleet.html', fleet=fleet_to_edit, fleetID=fleetID)

@app.route('/dashboard/add_fleet', methods=['GET', 'POST'])
def add_fleet():
    if 'managerID' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'GET':
        # Render the add_fleet.html template
        return render_template('add_fleet.html')
    
    # Handle POST request to add a new fleet
    desc = request.form.get('desc')
    capacity = request.form.get('capacity')
    status = request.form.get('status')
    plugin = request.form.get('plugin')

    # Check for empty values
    if not desc or not capacity or not status or not plugin:
        flash('All fields are required', 'error')
        return redirect(request.referrer)

    try:
        fleetID = fleet.getLatestFleetID()
        availability = capacity
        fleet.createFleet(int(fleetID), desc, int(capacity), int(availability), status, int(plugin))
        manager.addFleet(int(session['managerID']), int(fleetID))
        flash('Fleet added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    except ValueError:
        flash('Invalid values', 'error')
        return redirect(request.referrer)


@app.route('/dashboard/delete_fleet/<fleet_id>', methods=['POST'])
def delete_fleet(fleet_id):
    if 'managerID' not in session:
        return redirect(url_for(''))
    
    # Ask for confirmation before deleting
    if request.form.get('confirm_delete') == 'true':
        # Delete the fleet and remove it from the manager's list of fleets
        fleet.deleteFleet(fleet_id)
        manager.removeFleet(session['managerID'], fleet_id)
        flash('Fleet deleted successfully!', 'success')
    else:
        flash('Delete operation cancelled', 'warning')
        
    return redirect(url_for('dashboard'))


#VEHICLE STUFF
@app.route('/vehicles/<fleet_id>', methods=['GET'])
def get_vehicles_by_fleet_id(fleet_id):
    try:
        vehicles = vehicle.getFleetByID(int(fleet_id))
        return render_template('vehicles.html', vehicles=vehicles, fleet_id=fleet_id)
    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/vehicles/<int:fleet_id>/<int:vehicle_id>/edit', methods=['GET', 'POST'])
def edit_vehicle(fleet_id, vehicle_id):
    # Get the fleet and vehicle objects from the database
    fleet_obj = fleet.getFleetByID(fleet_id)
    vehicle_obj = vehicle.getVehicleByID(vehicle_id)

    if vehicle_obj is None:
        # Handle case when vehicle is not found
        flash("Vehicle not found", "error")
        return redirect(url_for('get_vehicles_by_fleet_id', fleet_id=fleet_id))

    if request.method == 'POST':
        # Update vehicle information
        # Get the updated values from the form
        vehiclePlates = request.form.get('vehiclePlates')
        vehicleSize = request.form.get('vehicleSize')
        vehicleLong = request.form.get('vehicleLong')
        vehicleLat = request.form.get('vehicleLat')
        vehicleStatus = request.form.get('vehicleStatus')
        fleetID = request.form.get('fleetID')

        # Check if any of the required keys are missing
        if not all([vehiclePlates, vehicleSize, vehicleLong, vehicleLat, vehicleStatus, fleetID]):
            flash("Missing form data", "error")
            return redirect(url_for('edit_vehicle', fleet_id=fleet_id, vehicle_id=vehicle_id))

        # Get the fleet object of the original fleet
        old_fleet_obj = fleet.getFleetByID(vehicle_obj['fleetID'])

        # Update the vehicle object with the new values
        vehicle.setVehiclePlates(vehicle_id, vehiclePlates)
        vehicle.setVehicleSize(vehicle_id, vehicleSize)
        vehicle.setVehicleLong(vehicle_id, float(vehicleLong))
        vehicle.setVehicleLat(vehicle_id, float(vehicleLat))
        vehicle.setVehicleStatus(vehicle_id, vehicleStatus)
        vehicle.setFleetID(vehicle_id, int(fleetID))

        # Get the fleet object of the new fleet
        new_fleet_obj = fleet.getFleetByID(int(fleetID))

        # Update fleet availability
        if old_fleet_obj is not None:
            old_fleet_obj['fleetAvailability'] += 1
            fleet.setFleetAvailability(old_fleet_obj['fleetID'], old_fleet_obj['fleetAvailability'])

        if new_fleet_obj is not None:
            new_fleet_obj['fleetAvailability'] -= 1
            fleet.setFleetAvailability(int(fleetID), new_fleet_obj['fleetAvailability'])

        # Flash a success message and redirect to the vehicles page
        flash("Vehicle updated successfully", "success")
        return redirect(url_for('get_vehicles_by_fleet_id', fleet_id=fleet_id))

    fleets = fleet.getAllFleetIDs()  # Get all fleet IDs from the database
    fleet_ids = [str(fleet['fleetID']) for fleet in fleets]  # Extract the fleet IDs as strings

    return render_template('edit_vehicle.html', fleet=fleet_obj, vehicle=vehicle_obj, fleet_ids=fleet_ids)


@app.route('/add-vehicle/<int:fleet_id>', methods=['POST', 'GET'])
def add_vehicle(fleet_id):
    if request.method == 'GET':
        return render_template('add_vehicle.html', fleet_id=fleet_id)
    else:
        vehicleID = vehicle.getLatestVehicleID()
        vehicleStatus = "Available"
        vehicleLong = float(request.form['vehicleLong'])
        vehicleLat = request.form['vehicleLat']
        vehicleSize = request.form['vehicleSize']
        vehicleDesc = request.form['vehicleDesc']
        vehiclePlates = request.form['vehiclePlates']
        vehicleVIN = request.form['vehicleVIN']
        vehicleFlags = 1

        # Get fleet object by ID
        fleet_obj = fleet.getFleetByID(fleet_id)

        # Check if fleet exists
        if fleet_obj is None:
            # Handle case when fleet is not found
            flash("Fleet not found", "error")
            return redirect(url_for('dashboard'))

        # Check if vehicle already exists in the fleet
        existing_vehicle = vehicle.getVehicleByID(vehicleID)
        if existing_vehicle is not None:
            flash("Vehicle already exists in the fleet", "error")
            return redirect(url_for('add_vehicle', fleet_id=fleet_id))

        # Create new vehicle
        vehicle.createVehicle(vehicleID, vehicleStatus, vehicleLong, vehicleLat, vehicleSize, vehicleDesc, vehicleVIN, vehiclePlates, fleet_id, vehicleFlags)

        # Decrease fleet availability
        fleet_obj['fleetAvailability'] -= 1
        fleet.setFleetAvailability(int(fleet_id), fleet_obj['fleetAvailability'])

        # Use PRG pattern to redirect to new page
        flash("Vehicle added successfully", "success")
        return redirect(url_for('show_vehicles', fleet_id=fleet_id))

@app.route('/show-vehicles/<int:fleet_id>')
def show_vehicles(fleet_id):
    # Get fleet object by ID
    fleet_obj = fleet.getFleetByID(fleet_id)

    # Check if fleet exists
    if fleet_obj is None:
        # Handle case when fleet is not found
        flash("Fleet not found", "error")
        return redirect(url_for('dashboard'))

    # Get list of vehicles for fleet
    vehicles = vehicle.getFleetByID(fleet_id)

    # Render template with vehicles
    return render_template('show_vehicles.html', fleet_id=fleet_id, vehicles=vehicles)

@app.route('/fleet/<int:fleet_id>/vehicles/<int:vehicle_id>/delete', methods=['POST'])
def delete_vehicle(fleet_id, vehicle_id):
    if request.method == 'POST' and request.form.get('confirm_delete') == 'true':
        # Find the corresponding vehicle instance
        vehicle_obj = vehicle.getVehicleByID(vehicle_id)
        if vehicle_obj:
            # Get fleet object by ID
            fleet_obj = fleet.getFleetByID(fleet_id)

            # Check if fleet exists
            if fleet_obj is None:
                # Handle case when fleet is not found
                flash("Fleet not found", "error")
                return redirect(url_for('dashboard'))

            # Delete the vehicle using the deleteVehicle() method
            vehicle.deleteVehicle(vehicle_id)

            # Increase fleet capacity
            fleet_obj['vehicleCapacity'] += 1
            fleet.setFleetCapacity(fleet_id, fleet_obj['fleetCapacity'])

            flash('Vehicle successfully deleted.')
    return redirect(url_for('show_vehicles', fleet_id=fleet_id))

@app.route('/vehicles_with_flags', methods=['GET'])
def vehicles_with_flags():
    vehicles = vehicle.getAllVehicles()
    vehicles_with_flags = []

    for vehicle_object in vehicles:
        flag_ids = vehicle_object['flagID']
        if 1 in [flag_ids]:
            continue
        vehicle_with_flags = {'vehicleID': int(vehicle_object['vehicleID']), 'flags': []}
        flag_info = []  # Move flag_info inside the loop
        for flag_id in flag_ids:
            flag_desc = flag.getFlagDesc(flag_id)
            flag_name = flag.getFlagName(flag_id)
            if flag_desc and flag_name:
                flag_info.append({'flagID': flag_id, 'flagName': flag_name, 'flagDesc': flag_desc})
        vehicle_with_flags['flags'] = flag_info
        vehicles_with_flags.append(vehicle_with_flags)

    return render_template('vehicles_with_flags.html', vehicles_with_flags=vehicles_with_flags)

@app.route('/create_manager', methods=['POST'])
def create_manager():
    username = request.form['username']
    password = request.form['password']
    email = request.form['email']
    phonenumber = request.form['phonenumber']
    dateHired = request.form['dateHired']
    salary = request.form['salary']
    fleets = request.form['fleets']

    # check if username and email already exist in the database
    existing_manager = manager.isUsernameUnique(username)
    if existing_manager:
        return jsonify({'message': 'Username already exists.'})
    existing_manager = manager.isEmailUnique(email)
    if existing_manager:
        return jsonify({'message': 'Email already exists.'})

    managerID = manager.getLatestManager()

    # create a new manager
    manager.createUser(managerID, username, password, email, phonenumber, dateHired, salary, fleets)

    return render_template('create_manager.html')

if __name__ == '__main__':
    app.run(debug=True)
