const editUsernameBtn = document.getElementById('edit-username-btn');
const saveUsernameBtn = document.getElementById('save-username-btn');
const usernameInput = document.getElementById('username');

editUsernameBtn.addEventListener('click', () => {
  usernameInput.disabled = false;
  editUsernameBtn.style.display = 'none';
  saveUsernameBtn.style.display = 'block';
});

saveUsernameBtn.addEventListener('click', () => {
  document.getElementById('edit-username-form').submit();
});

const editNameBtn = document.getElementById('edit-name-btn');
const saveNameBtn = document.getElementById('save-name-btn');
const nameInput = document.getElementById('name');

editNameBtn.addEventListener('click', () => {
  nameInput.disabled = false;
  editNameBtn.style.display = 'none';
  saveNameBtn.style.display = 'block';
});

saveNameBtn.addEventListener('click', () => {
  document.getElementById('edit-name-form').submit();
});

const editEmailBtn = document.getElementById('edit-email-btn');
const saveEmailBtn = document.getElementById('save-email-btn');
const emailInput = document.getElementById('email');

editEmailBtn.addEventListener('click', () => {
  emailInput.disabled = false;
  editEmailBtn.style.display = 'none';
  saveEmailBtn.style.display = 'block';
});

saveEmailBtn.addEventListener('click', () => {
  document.getElementById('edit-email-form').submit();
});

const editPhoneBtn = document.getElementById('edit-phonenumber-btn');
const savePhoneBtn = document.getElementById('save-phonenumber-btn');
const phoneInput = document.getElementById('phonenumber');

editPhoneBtn.addEventListener('click', () => {
  phoneInput.disabled = false;
  editPhoneBtn.style.display = 'none';
  savePhoneBtn.style.display = 'block';
});

savePhoneBtn.addEventListener('click', () => {
  document.getElementById('edit-phonenumber-form').submit();
});
