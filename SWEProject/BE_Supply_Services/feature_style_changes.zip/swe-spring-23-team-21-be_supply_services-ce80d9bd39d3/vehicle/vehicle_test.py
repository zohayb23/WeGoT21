from bson import ObjectId
import unittest
from vehicle_manager import VehicleManager

class TestVehicleManager(unittest.TestCase):
    def setUp(self):
        # Create an instance of the VehicleManager class
        self.vehicle = VehicleManager()

    def test_create_vehicle(self):
        # Create a test vehicle
        vehicle_id = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle", "1234567890", "ABC123", "fleet1", ["flag1"])

        # Get vehicle by ID
        vehicle = self.vehicle.getVehicleByID(vehicle_id)

        # Check if vehicle was created successfully
        self.assertEqual(vehicle['status'], "active")
        self.assertAlmostEqual(vehicle['latitude'], 12.34, places=2)
        self.assertAlmostEqual(vehicle['longitude'], 56.78, places=2)
        self.assertEqual(vehicle['size'], "large")
        self.assertEqual(vehicle['description'], "Test vehicle")
        self.assertEqual(vehicle['phone_number'], "1234567890")
        self.assertEqual(vehicle['license_plate'], "ABC123")
        self.assertEqual(vehicle['fleet_id'], "fleet1")
        self.assertEqual(vehicle['flags'], ["flag1"])

    def test_get_vehicle_by_id(self):
        # Create a test vehicle
        vehicle_id = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle", "1234567890", "ABC123", "fleet1", ["flag1"])

        # Get vehicle by ID
        vehicle = self.vehicle.getVehicleByID(vehicle_id)

        # Check if vehicle was retrieved correctly
        self.assertEqual(vehicle['_id'], vehicle_id)

    def test_get_all_vehicles(self):
        # Create test vehicles
        vehicle_id1 = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle 1", "1234567890", "ABC123", "fleet1", ["flag1"])
        vehicle_id2 = self.vehicle.create_vehicle("inactive", 98.76, 54.32, "small", "Test vehicle 2", "0987654321", "XYZ789", "fleet2", ["flag2"])

        # Get all vehicles
        vehicles = self.vehicle.getAllVehicles()

        # Check if all vehicles were retrieved correctly
        self.assertEqual(len(vehicles), 2)
        self.assertEqual(vehicles[0]['_id'], vehicle_id1)
        self.assertEqual(vehicles[1]['_id'], vehicle_id2)

    def test_get_vehicles_by_fleet(self):
        # Create test vehicles
        vehicle_id1 = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle 1", "1234567890", "ABC123", "fleet1", ["flag1"])
        vehicle_id2 = self.vehicle.create_vehicle("inactive", 98.76, 54.32, "small", "Test vehicle 2", "0987654321", "XYZ789", "fleet1", ["flag2"])
        vehicle_id3 = self.vehicle.create_vehicle("active", 11.11, 22.22, "medium", "Test vehicle 3", "9876543210", "DEF456", "fleet2", ["flag3"])

        # Get vehicles by fleet
        vehicles_fleet1 = self.vehicle.getVehiclesByFleet("fleet1")
        vehicles_fleet2 = self.vehicle.getVehiclesByFleet("fleet2")

                # Check if vehicles were retrieved correctly
        self.assertEqual(len(vehicles_fleet1), 2)
        self.assertEqual(len(vehicles_fleet2), 1)
        self.assertEqual(vehicles_fleet1[0]['_id'], vehicle_id1)
        self.assertEqual(vehicles_fleet1[1]['_id'], vehicle_id2)
        self.assertEqual(vehicles_fleet2[0]['_id'], vehicle_id3)

    def test_update_vehicle_status(self):
        # Create a test vehicle
        vehicle_id = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle", "1234567890", "ABC123", "fleet1", ["flag1"])

        # Update vehicle status
        self.vehicle.updateVehicleStatus(vehicle_id, "inactive")

        # Get updated vehicle
        vehicle = self.vehicle.getVehicleByID(vehicle_id)

        # Check if vehicle status was updated correctly
        self.assertEqual(vehicle['status'], "inactive")

    def test_set_get_vehicle_desc(self):
        # Create a test vehicle
        vehicle_id = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle", "1234567890", "ABC123", "fleet1", ["flag1"])

        # Set vehicle description
        self.vehicle.setVehicleDescription(vehicle_id, "Updated vehicle description")

        # Get updated vehicle
        vehicle = self.vehicle.getVehicleByID(vehicle_id)

        # Check if vehicle description was updated correctly
        self.assertEqual(vehicle['description'], "Updated vehicle description")

    def test_set_get_flag_id(self):
        # Create a test vehicle
        vehicle_id = self.vehicle.create_vehicle("active", 12.34, 56.78, "large", "Test vehicle", "1234567890", "ABC123", "fleet1", ["flag1"])

        # Set flag ID
        self.vehicle.setFlagID(vehicle_id, "flag2")

        # Get updated vehicle
        vehicle = self.vehicle.getVehicleByID(vehicle_id)

        # Check if flag ID was updated correctly
        self.assertIn("flag2", vehicle['flags'])

if __name__ == '__main__':
    unittest.main()
