from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId

# Recording class with Setters and Getters for all recording attributes
class Recording:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.recording_collection = self.client['WeGoSupply']['recordings']
        self.vehicle_colletion = self.client['WeGoSupply']['vehicles']

    def createRecording(self, recordingID, desc, URL, vehicleID):
        recording_data = {'recordingID': recordingID, 'recordingDesc': desc, 'recordingURL': URL, 'vehicleID': vehicleID }
        try:
            self.recording_collection.insert_one(recording_data)
        except DuplicateKeyError:
            return False
        return True
    
    def getLatestRecordingID(self):
        all_recordings = list(self.recording_collection.find())
        all_recordings.sort(key=lambda x: x['recordingID'], reverse=True)
        
        # Retrieve the latest managerID from the sorted list
        latest_recording = all_recordings[0] if all_recordings else None
        if latest_recording:
            recordingID = int(latest_recording['recordingID']) + 1
        else:
            recordingID = 1

        return recordingID

    def setRecordingsDesc(self, id, desc):
        try: 
            self.recording_collection.update_one(
                {'recordingID': id},
                { '$set': { 'recordingDesc': desc } }
            )
        except InvalidId:
            return False
        return True
    
    def getRecordingsDesc(self, id):

        recording = self.recording_collection.find_one({'recordingID': id})
        if recording:
            desc = recording.get('recordingDesc')
            return desc
        else:
            return None

    
    def setRecordingsUrl(self, id, URL):
        try: 
            self.recording_collection.update_one(
                {'recordingID': id},
                { '$set': { 'recordingURL': URL } }
            )
        except InvalidId:
            return False
        return True
    
    def getRecordingsUrl(self, id):
        recording = self.recording_collection.find_one({'recordingID': id})
        if recording:
            url = recording.get('recordingURL')
            return url
        else:
            return None
    
    def setRecordingsVehicleRef(self, id, vehicleID):
        try: 
            self.recording_collection.update_one(
                {'recordingID': id},
                { '$set': { 'vehicleID': vehicleID } }
            )
        except InvalidId:
            return False
        return True
    
    def getRecordingsFromVehicleRef(self, vehicleID):
        recordings = list(self.recording_collection.find({'vehicleID': vehicleID}))
        if recordings:
            return recordings
        else:
            return None

#ADD DELETE RECORDING METHOD