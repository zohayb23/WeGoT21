import unittest
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId
from fleet import Fleet

class TestFleet(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        # Set up a connection to the test database
        cls.fleet = Fleet()
        
    def setUp(self):
        # Create a new fleet before each test
        self.fleetID = self.fleet.getLatestFleetID()
        self.fleet.createFleet(self.fleetID,'name', 'test fleet', 10, True, 'active', 1)
        
    def tearDown(self):
        # Remove the test fleet after each test
        self.fleet.fleet_collection.delete_one({'fleetID': self.fleetID})
    
    def test_create_fleet(self):
        # Test that a new fleet can be created
        fleetID = self.fleet.getLatestFleetID()
        result = self.fleet.createFleet(fleetID,'name1', 'new fleet', 5, False, 'inactive', 2)
        self.assertTrue(result)
        fleet = self.fleet.getFleetByID(fleetID)
        self.assertEqual(fleet['fleetName'], 'name1')
        self.assertEqual(fleet['fleetDesc'], 'new fleet')
        self.assertEqual(fleet['fleetCapacity'], 5)
        self.assertFalse(fleet['fleetAvailability'])
        self.assertEqual(fleet['fleetStatus'], 'inactive')
        self.assertEqual(fleet['pluginID'], 2)
        
    def test_duplicate_fleet(self):
        # Test that creating a duplicate fleet returns False
        result = self.fleet.createFleet(self.fleetID,'name3' ,'duplicate fleet', 5, False, 'inactive', 2)
        self.assertTrue(result)
        
    def test_get_latest_fleet_id(self):
        # Test that the latest fleet ID is returned correctly
        fleetID = self.fleet.getLatestFleetID()
        self.assertIsInstance(fleetID, int)
        
    def test_get_fleet_by_id(self):
        # Test that a fleet can be retrieved by its ID
        fleet = self.fleet.getFleetByID(self.fleetID)
        self.assertIsNotNone(fleet)
        self.assertEqual(fleet['fleetDesc'], 'test fleet')
        
    def test_get_fleet_name(self):
        # Test that a fleet name can be retrieved by its ID
        name = self.fleet.getFleetName(self.fleetID)
        self.assertIsNotNone(name)
        self.assertEqual(name, 'name')
        
    def test_set_fleet_name(self):
        # Test that a fleet name can be set by its ID
        result = self.fleet.setFleetName(self.fleetID, 'new name')
        self.assertTrue(result)
        name = self.fleet.getFleetName(self.fleetID)
        self.assertEqual(name, 'new name')
        
    def test_get_fleet_desc(self):
        # Test that a fleet description can be retrieved by its ID
        desc = self.fleet.getFleetDesc(self.fleetID)
        self.assertIsNotNone(desc)
        self.assertEqual(desc, 'test fleet')
        
    def test_set_fleet_desc(self):
        # Test that a fleet description can be set by its ID
        result = self.fleet.setFleetDesc(self.fleetID, 'new description')
        self.assertTrue(result)
        desc = self.fleet.getFleetDesc(self.fleetID)
        self.assertEqual(desc, 'new description')
        
    def test_get_fleet_capacity(self):
        # Test that a fleet capacity can be retrieved by its ID
        capacity = self.fleet.getFleetCapacity(self.fleetID)
        self.assertIsNotNone(capacity)
        self.assertEqual(capacity, 10) 

    def test_set_fleet_capacity(self):
        # Test that a fleet capacity can be set by its ID
        result = self.fleet.setFleetCapacity(self.fleetID, 20)
        self.assertTrue(result)
        capacity = self.fleet.getFleetCapacity(self.fleetID)
        self.assertEqual(capacity, 20)
        
    def test_get_fleet_availability(self):
        # Test that a fleet availability can be retrieved by its ID
        availability = self.fleet.getFleetAvailability(self.fleetID)
        self.assertIsNotNone(availability)
        self.assertTrue(availability)
        
    def test_set_fleet_availability(self):
        # Test that a fleet availability can be set by its ID
        result = self.fleet.setFleetAvailability(self.fleetID, False)
        self.assertTrue(result)
        availability = self.fleet.getFleetAvailability(self.fleetID)
        self.assertFalse(availability)
        
    def test_get_fleet_status(self):
        # Test that a fleet status can be retrieved by its ID
        status = self.fleet.getFleetStatus(self.fleetID)
        self.assertIsNotNone(status)
        self.assertEqual(status, 'active')
        
    def test_set_fleet_status(self):
        # Test that a fleet status can be set by its ID
        result = self.fleet.setFleetStatus(self.fleetID, 'inactive')
        self.assertTrue(result)
        status = self.fleet.getFleetStatus(self.fleetID)
        self.assertEqual(status, 'inactive')
        
    def test_get_fleet_plugin_id(self):
        # Test that a fleet plugin ID can be retrieved by its ID
        pluginID = self.fleet.getFleetPlugin(self.fleetID)
        self.assertIsNone(pluginID)
        self.assertEqual(pluginID, None)
        
    def test_set_fleet_plugin_id(self):
        #Test that a fleet plugin ID can be set by its ID
        result = self.fleet.setFleetPlugin(self.fleetID, 2)
        self.assertTrue(result)
        pluginID = self.fleet.getFleetPlugin(self.fleetID)
        self.assertEqual(pluginID, None)
        


if __name__ == '__main__':
    unittest.main()   
   
