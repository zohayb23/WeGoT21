import unittest
from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
import bcrypt
from bson.objectid import ObjectId
from bson.errors import InvalidId
from User import User # user import should've been User

class UserTest(unittest.TestCase):
    def setUp(self):
        # MongoDB database connection parameters. Replace <user> and <password> with your MongoDB username and password.
        mongo_db = 'flask_db'
        mongo_uri = 'mongodb://zohayb:password123@104.236.192.183:27017/flask_db'
        # Initialize the User object with test MongoDB connection details
        self.user = User(mongo_uri, mongo_db)
        # Add a test user to the test MongoDB database
        hashed_password = bcrypt.hashpw(
            "test_password".encode('utf-8'), bcrypt.gensalt())
        test_user = {
            "id": str(ObjectId()), "username": "test_user", "password": hashed_password}
        self.user.users.insert_one(test_user)
    def tearDown(self):
        # Drop the test users collection from the test MongoDB database
        self.user.users.drop()
    def test_create_user(self):
        # Test creating a new user with valid username and password
        result = self.user.create_user("new_user", "new_password")
        self.assertTrue(result)
        # Test creating a new user with existing username
        result = self.user.create_user("test_user", "new_password")
        self.assertFalse(result)
    def reset_password(self, id, new_password):
        hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        try:
            self.user.users.update_one({'id': id}, {'$set': {'password': hashed_password}})
        except InvalidId:
            return False
        except:
            return False
        return True
    def test_validate_user(self):
        # Test validating an existing user with correct password
        result = self.user.validate_user("test_user", "test_password")
        self.assertTrue(result)
        # Test validating an existing user with incorrect password
        result = self.user.validate_user("test_user", "incorrect_password")
        self.assertFalse(result)
        # Test validating a non-existing user
        result = self.user.validate_user("non_existing_user", "password")
        self.assertFalse(result)
    def test_login_user(self):
        # Test logging in an existing user with correct username and password
        result = self.user.login_user("test_user", "test_password")
        self.assertTrue(result)
        # Test logging in an existing user with incorrect password
        result = self.user.login_user("test_user", "incorrect_password")
        self.assertFalse(result)
        # Test logging in a non-existing user
        result = self.user.login_user("non_existing_user", "password")
        self.assertFalse(result)
    def test_logout_user(self):
        # Test logging out a user
        result = self.user.logout_user()
        self.assertTrue(result)
        
if __name__ == '__main__':
    unittest.main()
