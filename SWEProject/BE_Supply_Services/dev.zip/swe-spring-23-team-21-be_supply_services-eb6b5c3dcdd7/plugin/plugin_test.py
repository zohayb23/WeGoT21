import unittest
from plugin import Plugin


class TestPlugin(unittest.TestCase):


    def setUp(self):
        self.plugin = Plugin()


    def test_create_plugin(self):
        self.assertTrue(self.plugin.createPlugin(1, 'Plugin1', 'Plugin1 Description', 'Active'))
        self.assertTrue(self.plugin.createPlugin(2, 'Plugin2', 'Plugin2 Description', 'Inactive'))
        self.assertTrue(self.plugin.createPlugin(3, 'Plugin3', 'Plugin3 Description', 'Active'))


    def test_get_latest_plugin_id(self):
        self.plugin.createPlugin(1, 'Plugin1', 'Plugin1 Description', 'Inactive')
        self.plugin.createPlugin(2, 'Plugin2', 'Plugin2 Description', 'Active')
        self.plugin.createPlugin(3, 'Plugin3', 'Plugin3 Description', 'Inactive')
        self.assertEqual(self.plugin.getLatestPluginID(), 3)




    def test_set_plugin_name(self):
        self.assertTrue(self.plugin.createPlugin(1, 'Plugin1', 'Plugin1 Description', 'Active'))
        self.assertTrue(self.plugin.setPluginName(1, 'NewPluginName'))
        self.assertEqual(self.plugin.getPluginName(1), 'NewPluginName')


    def test_set_plugin_desc(self):
        self.assertTrue(self.plugin.createPlugin(2, 'Plugin2', 'Plugin2 Description', 'Inactive'))
        self.assertTrue(self.plugin.setPluginDesc(2, 'NewPluginDesc'))
        self.assertEqual(self.plugin.getPluginDesc(2), 'NewPluginDesc')


    def test_set_plugin_status(self):
        self.assertTrue(self.plugin.createPlugin(3, 'Plugin3', 'Plugin3 Description', 'Active'))
        self.assertTrue(self.plugin.setPluginStatus(3, 'Inactive'))
        self.assertEqual(self.plugin.getPluginStatus(3), 'Inactive')
if __name__ == '__main__':
    unittest.main()