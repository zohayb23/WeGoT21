from flask import Flask, jsonify, request, session, redirect, url_for, render_template, flash
import bcrypt
from pymongo import MongoClient
from manager.manager import Manager
from fleet.fleet import Fleet
from vehicle.vehicle import Vehicle
from flag.flag import Flag
import requests
from threading import Thread
import time

# Create instances of the Manager and Fleet classes
manager = Manager()
fleet = Fleet()
vehicle = Vehicle()
flag = Flag()

# Create a Flask app instance
app = Flask(__name__)

# Create a secret key for the session
app.secret_key = "SUPERSECRETKEYSHUSH"

# Set up the MongoDB client
# create a MongoClient instance
client = MongoClient('mongodb://zohayb:password123@104.236.192.183:27017/flask_db')
db = client.flask_db
collection = db.location_data


# Route for the login page
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get the username and password from the request form
        username = request.form['username']
        password = request.form['password']

        # Check if the user is authorized to log in
        if manager.loginUser(username, password):
            # Set session information
            session['managerID'] = str(manager.getUser(username)['managerID'])
            session['managerName'] = str(manager.getUser(username)['managerName'])
            session.permanent = True

            # Redirect to the dashboard
            return redirect(url_for('dashboard'))
        else:
            # Display an error message
            message = "Username and/or password incorrect"
            return render_template('login.html', error = message)
    else:
        try:
            session.get("managerID")
            if session.get("managerID"):
                return redirect(url_for('dashboard'))
            else:
                # Display the login page
                return render_template('login.html')
        except:
            # Display the login page
            return render_template('login.html')

# Route for the logout page
@app.route('/logout')
def logout():
    # Remove session information
    session.pop('managerID', None)
    session.pop('managerName', None)

    # Redirect to the login page
    return redirect(url_for('login'))

# Route for the account page
@app.route('/account', methods=['GET', 'POST'])
def account():
    if request.method == 'POST':
        try:
            managerID = int(session.get('managerID'))
        except:
            # Redirect to the login page
            return redirect(url_for('login'))
        # Retrieve the updated user information from the form
        username = request.form.get('username')
        name = request.form.get('name')
        email = request.form.get('email')
        phonenumber = request.form.get('phonenumber')
            # Convert to integer

        if 'username-submit' in request.form:
            manager.setManagerUsername(managerID, username)
            flash('Username updated successfully')

        elif 'name-submit' in request.form:
            # Update the user's name in MongoDB
            manager.setManagerName(managerID, name)
            flash('Name updated successfully')

        elif 'email-submit' in request.form:
            # Update the user's email in MongoDB
            manager.setManagerEmail(managerID, email)
            flash('Email updated successfully')

        elif 'phonenumber-submit' in request.form:
            # Update the user's phone number in MongoDB
            manager.setManagerPhonenumber(managerID, phonenumber)
            flash('Phone number updated successfully')

        elif 'password-submit' in request.form:
            # Update the user's password in MongoDB
            old_password = request.form['old_password']
            new_password = request.form['new_password']
            confirm_password = request.form['confirm_password']

            # Check if the old password entered matches the one in the database
            old_hashed_password = manager.getManagerPassword(managerID)
            old_password = old_password.encode('utf-8')
            if isinstance(old_password, str):
                old_password = old_password.encode('utf-8')

            if isinstance(old_hashed_password, str):
                old_hashed_password = old_hashed_password.encode('utf-8')

            if not bcrypt.checkpw(old_password, old_hashed_password):
                flash('Incorrect old password')
                return redirect(url_for('account'))

            # Check if the new password and confirmation match
            if new_password != confirm_password:
                flash('New password and confirmation do not match')
                return redirect(url_for('account'))

            # Hash the new password and update it in the database
            manager.resetPassword(managerID, new_password)
            flash('Password updated successfully')


        # Redirect the user back to the account page
        return redirect(url_for('account'))

    else:
        try:
             # Clear all flashed messages
            messages = ''
            for key in list(session.keys()):
                if key.startswith('_flashes'):
                    session.pop(key)

            managerID = int(session.get('managerID'))
             # Fetch the user's data from MongoDB
            username = manager.getManagerUsername(managerID)
            name = manager.getManagerName(managerID)
            email = manager.getManagerEmail(managerID)
            phonenumber = manager.getManagerPhonenumber(managerID)

            # Render the account page with the user's data
            return render_template('account.html', username=username, name=name, email=email, phonenumber=phonenumber, messages = messages)
        except:
            # Redirect to the login page
            return redirect(url_for('login'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'managerID' not in session:
        return redirect(url_for('login'))

    # Fetch all fleets
    fleets = manager.getManagerFleets(int(session['managerID']))

    if request.method == 'GET':
        # Render the fleet_dashboard.html template with the fleets data
        return render_template('dashboard.html', fleets=fleets)

@app.route('/dashboard/edit_fleet/<int:fleetID>', methods=['GET', 'POST'])
def edit_fleet(fleetID):
    if 'managerID' not in session:
        return redirect(url_for('dashboard'))

    # Fetch the fleet to edit from the database
    fleet_to_edit = fleet.getFleetByID(fleetID)
    fleetID = fleet_to_edit['fleetID']

    if request.method == 'POST':
        # Get the updated data from the form
        desc = request.form.get('desc')
        capacity = int(request.form.get('capacity'))
        availability = int(request.form.get('availability'))
        status = request.form.get('status')
        plugin = request.form.get('plugin')

        # If capacity is changed to a number lower than the current or new availability,
        # set availability to the same value and availability should never go higher than capacity
        if capacity < fleet_to_edit['fleetAvailability'] or capacity < availability:
            availability = capacity

        # Update the fleet with the new data
        fleet.setFleetDesc(fleetID, desc)
        fleet.setFleetCapacity(fleetID, capacity)
        fleet.setFleetAvailability(fleetID, availability)
        fleet.setFleetStatus(fleetID, status)
        fleet.setFleetPlugin(fleetID, plugin)

        flash('Fleet updated successfully!', 'success')
        return redirect(url_for('dashboard'))

    # Display the fleet information and edit form
    return render_template('edit_fleet.html', fleet=fleet_to_edit, fleetID=fleetID)

@app.route('/dashboard/add_fleet', methods=['GET', 'POST'])
def add_fleet():
    if 'managerID' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'GET':
        # Render the add_fleet.html template
        return render_template('add_fleet.html')
    
    # Handle POST request to add a new fleet
    name = request.form.get('name')
    desc = request.form.get('desc')
    capacity = request.form.get('capacity')
    status = request.form.get('status')
    plugin = request.form.get('plugin')

    # Check for empty values
    if not desc or not capacity or not status or not plugin:
        flash('All fields are required', 'error')
        return redirect(request.referrer)

    try:
        fleetID = fleet.getLatestFleetID()
        availability = capacity
        fleet.createFleet(int(fleetID), name, desc, int(capacity), int(availability), status, int(plugin))
        manager.addFleet(int(session['managerID']), int(fleetID))
        flash('Fleet added successfully!', 'success')
        return redirect(url_for('dashboard'))
    
    except ValueError:
        flash('Invalid values', 'error')
        return redirect(request.referrer)


@app.route('/dashboard/delete_fleet/<fleet_id>', methods=['POST'])
def delete_fleet(fleet_id):
    if 'managerID' not in session:
        return redirect(url_for(''))
    
    # Ask for confirmation before deleting
    if request.form.get('confirm_delete') == 'true':
        # Delete the fleet and remove it from the manager's list of fleets
        fleet.deleteFleet(fleet_id)
        manager.removeFleet(session['managerID'], fleet_id)
        flash('Fleet deleted successfully!', 'success')
    else:
        flash('Delete operation cancelled', 'warning')
        
    return redirect(url_for('dashboard'))


#VEHICLE STUFF
@app.route('/vehicles/<fleet_id>', methods=['GET'])
def get_vehicles_by_fleet_id(fleet_id):
    try:
        vehicles = vehicle.getFleetByID(int(fleet_id))
        return render_template('vehicles.html', vehicles=vehicles, fleet_id=fleet_id)
    except Exception as e:
        return f"An error occurred: {str(e)}"

@app.route('/vehicles/<int:fleet_id>/<int:vehicle_id>/edit', methods=['GET', 'POST'])
def edit_vehicle(fleet_id, vehicle_id):
    # Get the fleet and vehicle objects from the database
    fleet_obj = fleet.getFleetByID(fleet_id)
    vehicle_obj = vehicle.getVehicleByID(vehicle_id)

    if vehicle_obj is None:
        # Handle case when vehicle is not found
        flash("Vehicle not found", "error")
        return redirect(url_for('get_vehicles_by_fleet_id', fleet_id=fleet_id))

    if request.method == 'POST':
        # Update vehicle information
        # Get the updated values from the form
        vehiclePlates = request.form.get('vehiclePlates')
        vehicleSize = request.form.get('vehicleSize')
        vehicleLong = request.form.get('vehicleLong')
        vehicleLat = request.form.get('vehicleLat')
        vehicleStatus = request.form.get('vehicleStatus')
        fleetID = request.form.get('fleetID')

        # Check if any of the required keys are missing
        if not all([vehiclePlates, vehicleSize, vehicleLong, vehicleLat, vehicleStatus, fleetID]):
            flash("Missing form data", "error")
            return redirect(url_for('edit_vehicle', fleet_id=fleet_id, vehicle_id=vehicle_id))

        # Get the fleet object of the original fleet
        old_fleet_obj = fleet.getFleetByID(vehicle_obj['fleetID'])

        # Update the vehicle object with the new values
        vehicle.setVehiclePlates(vehicle_id, vehiclePlates)
        vehicle.setVehicleSize(vehicle_id, vehicleSize)
        vehicle.setVehicleLong(vehicle_id, float(vehicleLong))
        vehicle.setVehicleLat(vehicle_id, float(vehicleLat))
        vehicle.setVehicleStatus(vehicle_id, vehicleStatus)
        vehicle.setFleetID(vehicle_id, int(fleetID))

        # Get the fleet object of the new fleet
        new_fleet_obj = fleet.getFleetByID(int(fleetID))

        # Update fleet availability
        if old_fleet_obj is not None:
            old_fleet_obj['fleetAvailability'] += 1
            fleet.setFleetAvailability(old_fleet_obj['fleetID'], old_fleet_obj['fleetAvailability'])

        if new_fleet_obj is not None:
            new_fleet_obj['fleetAvailability'] -= 1
            fleet.setFleetAvailability(int(fleetID), new_fleet_obj['fleetAvailability'])

        # Flash a success message and redirect to the vehicles page
        flash("Vehicle updated successfully", "success")
        return redirect(url_for('get_vehicles_by_fleet_id', fleet_id=fleet_id))

    fleets = fleet.getAllFleetIDs()  # Get all fleet IDs from the database
    fleet_ids = [str(fleet['fleetID']) for fleet in fleets]  # Extract the fleet IDs as strings

    return render_template('edit_vehicle.html', fleet=fleet_obj, vehicle=vehicle_obj, fleet_ids=fleet_ids)


@app.route('/add-vehicle/<int:fleet_id>', methods=['POST', 'GET'])
def add_vehicle(fleet_id):
    if request.method == 'GET':
        return render_template('add_vehicle.html', fleet_id=fleet_id)
    else:
        vehicleID = vehicle.getLatestVehicleID()
        vehicleStatus = "Available"
        #default is St. Eds, updated through heartbeat
        vehicleLong = float(-97.758520)
        vehicleLat = float(30.232365)
        vehicleSize = request.form['vehicleSize']
        vehicleDesc = request.form['vehicleDesc']
        vehiclePlates = request.form['vehiclePlates']
        vehicleVIN = request.form['vehicleVIN']
        vehicleFlags = 1

        # Get fleet object by ID
        fleet_obj = fleet.getFleetByID(fleet_id)

        # Check if fleet exists
        if fleet_obj is None:
            # Handle case when fleet is not found
            flash("Fleet not found", "error")
            return redirect(url_for('dashboard'))

        # Check if vehicle already exists in the fleet
        existing_vehicle = vehicle.getVehicleByID(vehicleID)
        if existing_vehicle is not None:
            flash("Vehicle already exists in the fleet", "error")
            return redirect(url_for('add_vehicle', fleet_id=fleet_id))

        # Create new vehicle
        vehicle.createVehicle(vehicleID, vehicleStatus, vehicleLong, vehicleLat, vehicleSize, vehicleDesc, vehicleVIN, vehiclePlates, fleet_id, vehicleFlags)

        # Decrease fleet availability
        fleet_obj['fleetAvailability'] -= 1
        fleet.setFleetAvailability(int(fleet_id), fleet_obj['fleetAvailability'])

        # Use PRG pattern to redirect to new page
        flash("Vehicle added successfully", "success")
        return redirect(url_for('show_vehicles', fleet_id=fleet_id))

@app.route('/show-vehicles/<int:fleet_id>')
def show_vehicles(fleet_id):
    # Get fleet object by ID
    fleet_obj = fleet.getFleetByID(fleet_id)

    # Check if fleet exists
    if fleet_obj is None:
        # Handle case when fleet is not found
        flash("Fleet not found", "error")
        return redirect(url_for('dashboard'))

    # Get list of vehicles for fleet
    vehicles = vehicle.getFleetByID(fleet_id)

    # Render template with vehicles
    return render_template('show_vehicles.html', fleet_id=fleet_id, vehicles=vehicles)

@app.route('/fleet/<int:fleet_id>/vehicles/<int:vehicle_id>/delete', methods=['POST'])
def delete_vehicle(fleet_id, vehicle_id):
    if request.method == 'POST' and request.form.get('confirm_delete') == 'true':
        # Find the corresponding vehicle instance
        vehicle_obj = vehicle.getVehicleByID(vehicle_id)
        if vehicle_obj:
            # Get fleet object by ID
            fleet_obj = fleet.getFleetByID(fleet_id)

            # Check if fleet exists
            if fleet_obj is None:
                # Handle case when fleet is not found
                flash("Fleet not found", "error")
                return redirect(url_for('dashboard'))

            # Delete the vehicle using the deleteVehicle() method
            vehicle.deleteVehicle(vehicle_id)

            # Increase fleet capacity
            fleet_obj['fleetCapacity'] += 1
            fleet.setFleetCapacity(fleet_id, fleet_obj['fleetCapacity'])

            flash('Vehicle successfully deleted.')
    return redirect(url_for('show_vehicles', fleet_id=fleet_id))

@app.route('/vehicles_with_flags', methods=['GET'])
def vehicles_with_flags():
    vehicles = vehicle.getAllVehicles()
    vehicles_with_flags = []

    for vehicle_object in vehicles:
        flag_ids = vehicle_object['flagID']
        if 1 in [flag_ids]:
            continue
        vehicle_with_flags = {'vehicleID': int(vehicle_object['vehicleID']), 'flags': []}
        flag_info = []  # Move flag_info inside the loop
        for flag_id in flag_ids:
            flag_desc = flag.getFlagDesc(flag_id)
            flag_name = flag.getFlagName(flag_id)
            if flag_desc and flag_name:
                flag_info.append({'flagID': flag_id, 'flagName': flag_name, 'flagDesc': flag_desc})
        vehicle_with_flags['flags'] = flag_info
        vehicles_with_flags.append(vehicle_with_flags)

    return render_template('vehicles_with_flags.html', vehicles_with_flags=vehicles_with_flags)





# API STUFF DO NOT TOUCH!!!! TESTED. IF ISSUES PLEASE CONTACT ANNE OR JASON FIRST
@app.route('/location', methods=['POST'])
def store_location():

    # Get the location data from the request
    data = request.get_json()
    vehicle_id = data['vehicle_id']
    eta = data['eta']
    geo_lat = data['geo_lat']
    geo_long = data['geo_long']
    route = data['route']
    on_route = data['on_route']
    status = data['status']

    # Insert the location data into the collection. If primary key exists, update the row.
    query = {'vehicle_id': vehicle_id}
    update = {'$set': {'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long,
                       'route': route, 'on_route': on_route, 'status': status}}
    collection.update_one(query, update, upsert=True)

    return jsonify({'message': 'Location data stored successfully!'})

# Endpoint to retrieve find the first available vehicle


@app.route('/vehicle', methods=['GET'])
def find_available_vehicle():
    try:
        # Retrieve the first available vehicle from the collection
        query = {'status': 'available'}
        sort = [('eta', 1)]
        vehicle_data = collection.find_one(query, sort=sort)
        if vehicle_data is None:
            return jsonify({'error': 'No available vehicles found.'}), 404

        # Return vehicle id to demand side
        vehicle_id = vehicle_data['vehicle_id']
        eta = vehicle_data['eta']
        geo_lat = vehicle_data['geo_lat']
        geo_long = vehicle_data['geo_long']
        route = vehicle_data['route']
        on_route = vehicle_data['on_route']
        status = vehicle_data['status']

        return jsonify({'vehicle_id': vehicle_id, 'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long, 'route': route, 'on_route': on_route, 'status': status})
    except:
        return jsonify({'error': 'Failed to get vehicle in DB data.'}), 500


@app.route('/request_data', methods=['GET', 'POST'])
def request_data():

    data = request.get_json()
    order_id = data['order_id']
    status = "unavailable"
    # Extract the vehicle data from the response
    vehicle_id = data['vehicle_id']
    dropoff = data['dropoff_location']
    pickup = data['pickup_location']
    eta = data['eta']
    geo_location = {
        # Extract 'lat' from nested dictionary
        'lat': data['geo_location']['lat'],
        # Extract 'long' from nested dictionary
        'long': data['geo_location']['long']
    }
    route = data['route']
    on_route = data['on_route']

    # Update MongoDB with the order_id and status
    collection.update_one({'vehicle_id': vehicle_id},
                          {'$set': {'order_id': order_id, 'status': status, 'dropoff_location': dropoff, 'destination_location': pickup}})

    # Return the updated vehicle data
    return jsonify({
        'vehicle_id': vehicle_id,
        'eta': eta,
        'geo_location': geo_location,
        'route': route,
        'on_route': on_route,
        'order_id': order_id,
        'status': status
    })


# Endpoint to reset vehicle data
@app.route('/vehicle/reset/<vehicle_id>', methods=['POST'])
def reset_vehicle_data(vehicle_id):
    # Reset the vehicle data in the collection
    query = {'vehicle_id': int(vehicle_id)}
    update = {'$set': {'route': '', 'on_route': False, 'order_id': '', 'status': 'available', 'destination_location': ''}}
    collection.update_one(query, update)

    return jsonify({'message': 'Vehicle data reset successfully!'})

# Heartbeat endpoint to receive the latest location data from the autonomous vehicle
@app.route('/heartbeat', methods=['POST'])
def heartbeat():
    global latest_location_data
    data = request.get_json()
    latest_location_data = {
        'vehicle_id': data['vehicle_id'],
        'eta': data['eta'],
        'geo_lat': data['geo_lat'],
        'geo_long': data['geo_long'],
        'route': data['route'],
        'on_route': data['on_route'],
        'status': data['status']
    }

    requests.post('https://swesupply2023team21.xyz/location', json=latest_location_data)
    print("Heartbeat received")
    return jsonify({'message': 'Heartbeat recieved'})


@app.route('/request_vehicle')
def render_webpage():
    # Render the webpage with the form for user input
    return render_template('vehicle_request.html')

@app.route('/request', methods=['POST'])
def handle_request():
    # Get destination location and pickup location from the form data
    json_data = request.get_json()
    dropoff_location = json_data.get('dropoff_location')
    pickup_location = json_data.get('pickup_location')
    order_id = json_data.get('order_id')

    # Check if destination_location and pickup_location are provided
    if not dropoff_location or not pickup_location:
        return jsonify({'error': 'Both destination_location and pickup_location are required.'}), 400

    try:
        vehicle_request = requests.get('https://swesupply2023team21.xyz/vehicle')
        
        vehicle_data = vehicle_request.json()
        vehicle_request_JSON = {
            'vehicle_id': vehicle_data['vehicle_id'],
            'eta': vehicle_data['eta'],
            'geo_location': {
                'lat': vehicle_data['geo_lat'],
                'long': vehicle_data['geo_long']
            },
            'route': vehicle_data['route'],
            'on_route': vehicle_data['on_route'],
            'dropoff_location': dropoff_location,
            'pickup_location': pickup_location,
            'order_id': order_id # Generate a random order ID
        }

        try:
            requests.post('https://swesupply2023team21.xyz/request_data', json=vehicle_request_JSON)
            # requests.post('http://localhost:5002/dispatch', json=vehicle_request_JSON)

            return jsonify(vehicle_request_JSON)
        except:
            return jsonify({'error': 'Failed to get request data.'}), 500
    except:
        return jsonify({'error': 'Failed to get vehicle data.'}), 500

#Function to fetch heartbeat data every 5 seconds
def fetch_heartbeat_data():
    while True:
        heartbeat_data = db.location_data.find()
        # Convert ObjectId fields to strings and exclude the _id field
        heartbeat_data = [{k: v for k, v in data.items() if k != "_id"} for data in heartbeat_data]
        # for data in heartbeat_data: This part of the line iterates through each document in the heartbeat_data list. heartbeat_data is assumed to be a list of dictionaries, where each dictionary represents a document from a MongoDB collection.
        # data.items(): This part of the line retrieves all the key-value pairs from the data dictionary as a list of tuples. For example, if data is {"_id": 1, "name": "John", "age": 30}, then data.items() would return [("_id", 1), ("name", "John"), ("age", 30)].
        # if k != "_id": This part of the line is a conditional statement that checks if the key (k) is not equal to "_id". This is done to exclude the _id field from the filtered data.
        # {k: v for k, v in data.items() if k != "_id"}: This part of the line is a dictionary comprehension that creates a new dictionary for each data document, including only the key-value pairs where the key is not equal to "_id". This effectively filters out the _id field from the dictionary.
        # [{k: v for k, v in data.items() if k != "_id"} for data in heartbeat_data]: This part of the line is a list comprehension that iterates through each data document in heartbeat_data and applies the dictionary comprehension to create a new list of dictionaries, where each dictionary represents a filtered document without the _id field.
        app.heartbeat_data = heartbeat_data
        time.sleep(1)
#Create and start the heartbeat data fetching thread
heartbeat_thread = Thread(target=fetch_heartbeat_data)
heartbeat_thread.start()

#Endpoint to store location data for vehicle heartbeat
@app.route("/heartbeat_data", methods=['GET'])
def heartbeat_data():
    try:
        managerID = int(session.get('managerID'))
        heartbeat_data = app.heartbeat_data
        try:
            vehicles = vehicle.getAllVehicles()
            return render_template('review_vehicle.html', heartbeat_data=heartbeat_data, vehicles=vehicles)
        except Exception as e:
            return render_template('review_vehicle.html', heartbeat_data=heartbeat_data)
    except:
        # Redirect to the login page
        return redirect(url_for('login'))


# Endpoint to return the latest heartbeat data as JSON
@app.route("/heartbeat_data_json", methods=["GET"])
def heartbeat_data_json():
    heartbeat_data = db.location_data.find()
    # Convert ObjectId fields to strings and exclude the _id field
    heartbeat_data = [{k: v for k, v in data.items() if k != "_id"} for data in heartbeat_data]
    return jsonify(heartbeat_data)

if __name__ == "__main__":
    app.run(host='0.0.0.0')
