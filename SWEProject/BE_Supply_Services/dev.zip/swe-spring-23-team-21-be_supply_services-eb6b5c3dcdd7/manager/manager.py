from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
import bcrypt
from bson.errors import InvalidId
from bson.binary import Binary

class Manager:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.manager_collection = self.client['WeGoSupply']['managers']
        self.fleet_collection = self.client['WeGoSupply']['fleets']

    def createUser(self, managerID, username, password, name, email, phonenumber, dateHired, salary, fleets):
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(rounds=12, prefix=b'2b'))
                    
        user = { 'managerID': managerID, 'managerUsername': username, 'managerPassword': hashed, 'managerName': name, 'managerEmail': email, 
                'managerPhonenumber': phonenumber, 'managerDateHired': dateHired, 'managerSalary': salary, 'fleetID': fleets }
        
        try:
            self.manager_collection.insert_one(user)
        except DuplicateKeyError:
            return False
        return True
    
    def isUsernameUnique(self, username):
        
        existing_manager = self.manager_collection.find_one.filter_by(username=username).first()
        return existing_manager is None

    def isEmailUnique(self, email):
       
        existing_manager = self.manager_collection.find_one.filter_by(email=email).first()
        return existing_manager is None

    def getLatestManager(self):
        # Retrieve all users and sort them by managerID in descending order
        all_managers = list(self.manager_collection.find())
        all_managers.sort(key=lambda x: x['managerID'], reverse=True)
        
        # Retrieve the latest managerID from the sorted list
        latest_manager = all_managers[0] if all_managers else None
        if latest_manager:
            managerID = int(latest_manager['managerID']) + 1
        else:
            managerID = 1

        return managerID

    def getManagerUsername(self, id):
        
        username = self.manager_collection.find_one({'managerID': id})
        
        if username:
            return username['managerUsername']
        else:
            return None
    

    def setManagerUsername(self, id, new_username):
        # Check if the new_username is already in use
        if self.manager_collection.find_one({'managerUsername': new_username}):
            return False
            
        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerUsername': new_username } }
            )
        except InvalidId:
            return False
        
        return True

    def resetPassword(self, id, password):
        # Hash the password
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(rounds=12, prefix=b'2b'))
        
        # Convert the hashed password to a string and store it in the database
        hashed_password_str = hashed_password.decode('utf-8')
        self.manager_collection.update_one({'managerID': id}, {'$set': {'managerPassword': hashed_password_str}})
        
        return hashed_password_str

    def validateUser(self, username, password):
        user = self.manager_collection.find_one({'managerUsername': username})
        if user is None:
            return False

        hashed_password = user['managerPassword']

        # Convert the hashed password to bytes if it's a string
        if isinstance(hashed_password, str):
            hashed_password = hashed_password.encode('utf-8')

        password = password.encode('utf-8')

        # Compare the provided password with the stored hash
        if bcrypt.checkpw(password, hashed_password):
            return True

        return False

    def getUser(self, username):
        user = self.manager_collection.find_one({ 'managerUsername': username })
        return user

    def loginUser(self, username, password):
        if self.validateUser(username, password):
            return True
        return False

    def logoutUser(self):
        return True

    def getManagerPassword(self, id):
        password = self.manager_collection.find_one({'managerID': id})
        if password:
            return password['managerPassword']
        return None

    def setManagerName(self, id, name):
        
        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerName': name } }
            )
        except InvalidId:
            return False
        return True
    
    def getManagerName(self, id):
        name = self.manager_collection.find_one({'managerID': id})
        if name:
            return name['managerName']
        else:
            return None

    def setManagerEmail(self, id, new_email):
        # Check if the new_email is already in use
        if self.manager_collection.find_one({'managerEmail': new_email}):
            return False
            
        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerEmail': new_email } }
            )
        except InvalidId:
            return False
        
        return True
    
    def getManagerEmail(self, id):
        manager = self.manager_collection.find_one({'managerID': id})
        if manager:
            return manager['managerEmail']
        return None

    def getManagerName(self, id):
        manager = self.manager_collection.find_one({'managerID': id})
        if manager:
            return manager['managerName']
        return None

    def setManagerPhonenumber(self, id, new_phonenumber):
        
        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerPhonenumber': new_phonenumber } }
            )
        except InvalidId:
            return False
        return True

    def getManagerPhonenumber(self, id):
    
        manager = self.manager_collection.find_one({'managerID': id})
        if manager:
            return manager['managerPhonenumber']
        else:
            return None
    
    def setManagerDateHired(self, id, dateHired):
        
        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerDateHired': dateHired} }
            )
        except InvalidId:
            return False
        return True
    
    def getManagerDateHired(self, id):
   
        manager = self.manager_collection.find_one({'managerID': id})
        if manager:
            return manager['managerDateHired']
        else:
            return None

    
    def setManagerSalary(self, id, salary):

        try:
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'managerSalary': salary} }
            )
        except InvalidId:
            return False
        return True

    # def getManagerSalary(self, id):
    
    #     manager = self.manager_collection.find_one({'managerID': id})
    #     if manager:
    #         return manager['managerSalary']
    #     else:
    #         return None
    
    def setManagerFleets(self, id, fleets):

        try: 
            self.manager_collection.update_one(
                {'managerID': id},
                { '$set': { 'fleetID': fleets } }
            )
        except InvalidId:
            return False
        return True
    
    def getManagerFleets(self, id):
        manager = self.manager_collection.find_one({'managerID': id})
        if manager:
            fleet_ids = manager.get('fleetID', [])
            fleets = self.fleet_collection.find({'fleetID': {'$in': fleet_ids}})
            return list(fleets)
        else:
            return []

    def addFleet(self, manager_id, fleet_id):
        try:
            self.manager_collection.update_one(
                {'managerID': manager_id},
                {'$addToSet': {'fleetID': fleet_id}}
            )
        except InvalidId:
            return False
        return True
    
    def removeFleet(self, managerID, fleetID):
        # Find the manager document with the given managerID
        manager_doc = self.manager_collection.find_one({'managerID': managerID})

        # Check if the manager document exists
        if not manager_doc:
            return False

        # Get the list of fleet IDs for the manager
        fleet_ids = manager_doc.get('fleetID', [])

        # Check if the fleet ID to be removed is in the list
        if fleetID not in fleet_ids:
            return False

        # Remove the fleet ID from the list
        fleet_ids.remove(fleetID)

        # Update the manager document with the new fleet ID list
        self.manager_collection.update_one({'managerID': managerID}, {'$set': {'fleetID': fleet_ids}})

        return True
