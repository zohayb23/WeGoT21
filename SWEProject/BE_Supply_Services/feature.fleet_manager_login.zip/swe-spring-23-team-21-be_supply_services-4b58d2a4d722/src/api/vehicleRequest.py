from flask import Flask, request, jsonify, render_template
import requests
import uuid

app = Flask(__name__)

@app.route('/request_vehicle')
def render_webpage():
    # Render the webpage with the form for user input
    return render_template('vehicle_request.html')

@app.route('/request', methods=['POST'])
def handle_request():
    # Get destination location and pickup location from the form data
    dropoff_location = request.form.get('dropoff_location')
    pickup_location = request.form.get('pickup_location')

    # Check if destination_location and pickup_location are provided
    if not dropoff_location or not pickup_location:
        return jsonify({'error': 'Both destination_location and pickup_location are required.'}), 400

    try:
        vehicle_request = requests.get('http://localhost:5000/vehicle')

        vehicle_data = vehicle_request.json()

        vehicle_request_JSON = {
            'vehicle_id': vehicle_data['vehicle_id'],
            'eta': vehicle_data['eta'],
            'geo_location': {
                'lat': vehicle_data['geo_lat'],
                'long': vehicle_data['geo_long']
            },
            'route': vehicle_data['route'],
            'on_route': vehicle_data['on_route'],
            'dropoff_location': dropoff_location,
            'pickup_location': pickup_location,
            'order_id': str(uuid.uuid4())  # Generate a random order ID
        }

        requests.post('http://localhost:5000/request', json=vehicle_request_JSON)
        # requests.post('http://localhost:5002/dispatch', json=vehicle_request_JSON)

        return jsonify(vehicle_request_JSON)
    except:
        return jsonify({'error': 'Failed to get vehicle data.'}), 500

if __name__ == '__main__':
    app.run(debug=True)
