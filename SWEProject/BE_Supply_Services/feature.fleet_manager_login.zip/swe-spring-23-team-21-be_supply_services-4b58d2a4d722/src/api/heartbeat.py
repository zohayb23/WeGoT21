from flask import Flask, jsonify, request
import pymysql
import requests

app = Flask(__name__)

# Store the latest location data from the autonomous vehicle
latest_location_data = {}

# Heartbeat endpoint to receive the latest location data from the autonomous vehicle
@app.route('/heartbeat', methods=['GET','POST'])
def heartbeat():
    global latest_location_data
    data = request.get_json()
    latest_location_data = {
        'vehicle_id': data['vehicle_id'],
        'eta': data['eta'],
        'geo_lat': data['geo_lat'],
        'geo_long': data['geo_long'],
        'route': data['route'],
        'on_route': data['on_route'],
        'status': data['status']
    }

    requests.post('https://swesupply2023team21.xyz/location', json=latest_location_data)
    print("Heartbeat recieved")
    return jsonify({'message': 'Heartbeat recieved'})

# Location endpoint to retrieve the latest location data from the backend
@app.route('/location', methods=['GET', 'POST'])
def location():
    global latest_location_data
    if request.method == 'GET':
        return jsonify(latest_location_data)
    elif request.method == 'POST':
        data = request.get_json()
        # Save the new location data to the database
        # ...

        return jsonify({'message': 'Location data saved to DB'})



if __name__ == '__main__':
    app.run(port=0)
