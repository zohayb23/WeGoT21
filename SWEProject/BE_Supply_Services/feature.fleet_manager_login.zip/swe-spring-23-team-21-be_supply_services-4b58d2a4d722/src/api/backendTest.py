from flask import Flask, jsonify, request
from pymongo import MongoClient
import os

import requests

app = Flask(__name__)

user = os.environ.get('USER')
password = os.environ.get('PASSWORD')

# MongoDB database connection parameters
client = MongoClient('mongodb://Admin:Bonjour@104.236.192.183:27017/', 27017)
db = client['flask_db']
collection = db['location_data']

# Endpoint to store location data for vehicle heartbeat


@app.route('/location', methods=['POST'])
def store_location():

    # Get the location data from the request
    data = request.get_json()
    vehicle_id = data['vehicle_id']
    eta = data['eta']
    geo_lat = data['geo_lat']
    geo_long = data['geo_long']
    route = data['route']
    on_route = data['on_route']
    status = data['status']

    # Insert the location data into the collection. If primary key exists, update the row.
    query = {'vehicle_id': vehicle_id}
    update = {'$set': {'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long,
                       'route': route, 'on_route': on_route, 'status': status}}
    collection.update_one(query, update, upsert=True)

    return jsonify({'message': 'Location data stored successfully!'})

# Endpoint to retrieve find the first available vehicle


@app.route('/vehicle', methods=['GET'])
def find_available_vehicle():

    # Retrieve the first available vehicle from the collection
    query = {'status': 'available'}
    sort = [('eta', 1)]
    vehicle_data = collection.find_one(query, sort=sort)

    if vehicle_data is None:
        return jsonify({'message': 'No vehicles available'})

    # Return vehicle id to demand side
    vehicle_id = vehicle_data['vehicle_id']
    eta = vehicle_data['eta']
    geo_lat = vehicle_data['geo_lat']
    geo_long = vehicle_data['geo_long']
    route = vehicle_data['route']
    on_route = vehicle_data['on_route']
    status = vehicle_data['status']

    

    return jsonify({'vehicle_id': vehicle_id, 'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long, 'route': route, 'on_route': on_route, 'status': status})


@app.route('/request', methods=['GET', 'POST'])
def request_vehicle():

    data = request.get_json()
    order_id = data['order_id']
    status = "unavailable"
    # Extract the vehicle data from the response
    vehicle_id = data['vehicle_id']
    destination = data['dropoff_location']
    pickup = data['pickup_location']
    eta = data['eta']
    geo_location = {
        # Extract 'lat' from nested dictionary
        'lat': data['geo_location']['lat'],
        # Extract 'long' from nested dictionary
        'long': data['geo_location']['long']
    }
    route = data['route']
    on_route = data['on_route']

    # Update MongoDB with the order_id and status
    collection.update_one({'vehicle_id': vehicle_id},
                          {'$set': {'order_id': order_id, 'status': status, 'destination_location': destination, 'pickup_location': pickup}})

    # Return the updated vehicle data
    return jsonify({
        'vehicle_id': vehicle_id,
        'eta': eta,
        'geo_location': geo_location,
        'route': route,
        'on_route': on_route,
        'order_id': order_id,
        'status': status
    })


# Endpoint to reset vehicle data
@app.route('/vehicle/reset/<vehicle_id>', methods=['POST'])
def reset_vehicle_data(vehicle_id):
    # Reset the vehicle data in the collection
    query = {'vehicle_id': int(vehicle_id)}
    update = {'$set': {'route': '', 'on_route': False, 'order_id': '', 'status': 'available', 'destination_location': '', 'dropoff_location': ''}}
    collection.update_one(query, update)

    return jsonify({'message': 'Vehicle data reset successfully!'})

if __name__ == '__main__':
    app.run(port=0, debug=True)
