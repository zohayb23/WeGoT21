from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId

# Plugin class with Setters and Getters for all Plugin attributes
class Plugin:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.plugin_collection = self.client['WeGoSupply']['plugins']

    def createPlugin(self, pluginID, name, desc, status):
        create_plugin = {'pluginID': pluginID, 'pluginName': name, 'pluginDesc': desc, 'pluginStatus': status }
        try:
            self.plugin_collection.insert_one(create_plugin)
        except DuplicateKeyError:
            return False
        return True

    def getLatestPluginID(self):
        #Retrieve all plugins and sort them
        all_plugins = list(self.plugin_collection.find())
        all_plugins.sort(key=lambda x: x['pluginID'], reverse=True)
        
        # Retrieve the latest managerID from the sorted list
        latest_plugin = all_plugins[0] if all_plugins else None
        if latest_plugin:
            pluginiD = int(latest_plugin['pluginID']) + 1
        else:
            pluginID = 1
            
        return pluginID

    def setPluginName(self, id, name):
        try:
            self.plugin_collection.update_one(
                {'pluginID': id},
                { '$set': { 'pluginName': name } }
            )
        except InvalidId:
            return False
        return True

    def getPluginName(self, id):
        name = self.plugin_collection.find_one({'pluginID': id})
        if name:
            return name['pluginName']
        else:
            return None

    def setPluginDesc(self, id, desc):
        try:
            self.plugin_collection.update_one(
                {'pluginID': id},
                { '$set': { 'pluginDesc': desc } }
            )
        except InvalidId:
            return False
        return True

    def getPluginDesc(self, id):
        desc = self.plugin_collection.find_one({'pluginID': id})
        if desc:
            return desc['pluginDesc']
        else:
            return None

    def setPluginStatus(self, id, status):
        try:
            self.plugin_collection.update_one(
                {'pluginID': id},
                { '$set': { 'pluginStatus': status } }
            )
        except InvalidId:
            return False
        return True

    def getPluginStatus(self, id):
        
        status = self.plugin_collection.find_one({'pluginID': id})
        if status:
            return status['pluginStatus']
        else:
            return None
