import unittest
from pymongo import MongoClient
from manager.manager import manager

class ManagerTestCase(unittest.TestCase):

    def setUp(self):
        # Set up the MongoDB client and database
        self.client = MongoClient('mongodb://localhost:27017/')
        self.db = self.client['test_db']
        self.manager_collection = self.db['credentials']

        # Insert a test manager document
        manager_data = {
            'managerID': '1',
            'managerUsername': 'testuser',
            'managerPassword': 'testpassword',
            'managerName': 'Test User',
            'managerEmail': 'testuser@example.com',
            'managerPhonenumber': '1234567890',
            'managerDateHired': '2022-01-01',
            'managerSalary': 50000,
            'fleetID': []
        }
        self.manager_collection.insert_one(manager_data)

        # Instantiate the manager class with test MongoDB connection details
        self.manager = manager('mongodb://localhost:27017/', 'test_db')

    def tearDown(self):
        # Clean up the test manager document
        self.manager_collection.delete_one({'managerID': '1'})

        # Close the MongoDB client connection
        self.client.close()

    def test_setManagerFleets(self):
        # Test setting manager fleets
        fleets = ['fleet1', 'fleet2', 'fleet3']
        result = self.manager.setManagerFleets('1', fleets)
        self.assertTrue(result)

        # Test getting manager fleets
        retrieved_fleets = self.manager.getManagerFleets('1')
        self.assertEqual(fleets, retrieved_fleets)

    def test_getManagerFleets(self):
        # Test getting manager fleets for non-existent manager
        result = self.manager.getManagerFleets('2')
        self.assertIsNone(result)

    def test_setManagerFleets_with_invalid_manager_id(self):
        # Test setting manager fleets with invalid manager ID
        fleets = ['fleet1', 'fleet2', 'fleet3']
        result = self.manager.setManagerFleets('invalid_id', fleets)
        self.assertFalse(result)

    def test_setManagerFleets_with_nonexistent_manager_id(self):
        # Test setting manager fleets with nonexistent manager ID
        fleets = ['fleet1', 'fleet2', 'fleet3']
        result = self.manager.setManagerFleets('100', fleets)
        self.assertFalse(result)

if __name__ == '__main__':
    unittest.main()
