from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId

# Fleet class with setters and getters for all flag attributes
class Fleet:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.fleet_collection = self.client['WeGoSupply']['fleets']
        self.plugin_collection = self.client['WeGoSupply']['plugins']
        self.manager_collection = self.client['WeGoSupply']['managers']

    def createFleet(self, fleetID, name, desc, capacity, availability, status, plugin):
        # Create the new fleet document with the generated fleetID
        create_fleet = {'fleetID': fleetID, 'fleetName': name, 'fleetDesc': desc,'fleetCapacity': capacity,
                        'fleetAvailability': availability,'fleetStatus': status,'pluginID': plugin }
        try:
            self.fleet_collection.insert_one(create_fleet)
        except DuplicateKeyError:
            return False
        return True
    
    def getLatestFleetID(self):
        # Get the current value of the fleetID sequence, or create it if it doesn't exist
        all_fleets = list(self.fleet_collection.find())
        all_fleets = [f for f in all_fleets if 'fleetID' in f]
        all_fleets.sort(key=lambda x: x['fleetID'], reverse=True)
        
        # set initial flagID to 1 if no flag document is present
        latest_fleet = all_fleets[0] if all_fleets else None
        if latest_fleet:
            fleetID = int(latest_fleet['fleetID']) + 1
        else:
            fleetID = 1
        
        return fleetID
    
    def getFleetByID(self, id):

        fleet = self.fleet_collection.find_one({'fleetID': id})

        if fleet:
            return fleet
        else:
            None

    def setFleetName(self, id, name):

        try:
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'fleetName': name } } )
        except InvalidId:
            return False
        return True
        
    def getFleetName(self, id):

        name = self.fleet_collection.find_one({'fleetID': id})
        if name:
            return name['fleetName']
        else:
            return None

    def setFleetDesc(self, id, desc):

        try:
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'fleetDesc': desc } } )
        except InvalidId:
            return False
        return True
    
    def getFleetDesc(self, id):

        desc = self.fleet_collection.find_one({'fleetID': id})
        if desc:
            return desc['fleetDesc']
        else:
            return None
    
    def setFleetCapacity(self, id, capacity):

        try:
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'fleetCapacity': capacity } } )
        except InvalidId:
            return False
        return True
    
    def getFleetCapacity(self, id):

        capacity = self.fleet_collection.find_one({'fleetID': id})
        if capacity:
            return capacity['fleetCapacity']
        else:
            return None
    
    def setFleetAvailability(self, id, availability):

        try:
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'fleetAvailability': availability } } )
        except InvalidId:
            return False
        return True
    
    def getFleetAvailability(self, id):

        availability = self.fleet_collection.find_one({'fleetID': id})
        if availability:
            return availability['fleetAvailability']
        else:
            return None
    
    def setFleetStatus(self, id, status):

        try:
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'fleetStatus': status } } )
        except InvalidId:
            return False
        return True
    
    def getFleetStatus(self, id):

        status = self.fleet_collection.find_one({'fleetID': id})
        if status:
            return status['fleetStatus']
        else:
            return None
    
    def setFleetPlugin(self, id, plugin):

        try: 
            self.fleet_collection.update_one(
                {'fleetID': id},
                { '$set': { 'pluginID': plugin } } )
        except InvalidId:
            return False
        return True
    
    def getFleetPlugin(self, plugin):

        plugin_fleet = self.plugin_collection.find_one({'pluginID': plugin})
        if plugin_fleet:
            fleet_id = plugin_fleet['fleetID']
            fleet_data = self.fleet_collection.find_one({'_id': fleet_id})
            return fleet_data
        else:
            return None

    def deleteFleet(self, id):
        try:
            result = self.fleet_collection.delete_one({'fleetID': id})
            if result.deleted_count == 1:
                return True
            else:
                return False
        except InvalidId:
            return False
        
    def getFleetByID(self, id):

        fleet = self.fleet_collection.find_one({'fleetID': id})
        if fleet:
            return fleet
        else:
            return None

    def getAllFleetNames(self):
        fleets = self.fleet_collection.find({}, {'_id': 0, 'fleetID': 1, 'fleetName': 1})
        return {fleet['fleetName']: fleet['fleetID'] for fleet in fleets}
        
    def getFleetIDByName(self, name):

        fleet = self.fleet_collection.find_one({'fleetName': name})
        if fleet:
            return fleet['fleetId']
        else:
            return None
        
    def getFleetNameById(self, fleet_id):
        fleet = self.fleet_collection.find_one({'fleetId': fleet_id})
        if fleet:
            return fleet['fleetName']
        else:
            return None
        
    def getAllFleetIDs(self):

        fleetIDs = self.fleet_collection.find({}, {'fleetID': 1})
        if fleetIDs:
            return fleetIDs
        else:
            None
