import unittest
from flag import Flag

class TestFlag(unittest.TestCase):
    def setUp(self):
        self.flag = Flag()
        self.flag.createFlag(1, 'Test Flag Description', 'Test Flag')
        self.flag.createFlag(2, 'Another Test Flag Description', 'Another Test Flag')

    def test_create_flag(self):
        self.assertTrue(self.flag.createFlag(3, 'Duplicate Flag Description', 'Duplicate Flag'))

    def test_get_latest_flag_id(self):
        self.assertEqual(self.flag.getLatestFlagID(), 4)


    def test_get_flag_name(self):
        self.assertEqual(self.flag.getFlagName(1), 'Test Flag')

    
    def test_set_flag_name(self):
        self.assertTrue(self.flag.setFlagName(4, 'New Flag Name'))
        self.assertTrue(self.flag.setFlagName(1, 'Test Flag'))

    def test_set_flag_desc(self):
        self.assertTrue(self.flag.setFlagDesc(4, 'New Flag Description'))
        self.assertTrue(self.flag.setFlagDesc(1, 'Test Flag Description'))

if __name__ == '__main__':
    unittest.main()
