from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId

# Flag class with setters and getters for all flag attributes
class Flag:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.flag_collection = self.client['WeGoSupply']['flags']

    def createFlag(self, flagID, desc, name):
        create_flag = {'flagID': flagID, 'flagDesc': desc, 'flagName': name}
        try:
            self.flag_collection.insert_one(create_flag)
        except DuplicateKeyError:
            return False
        return True

    def getLatestFlagID(self):
        # get the latest flag document
        all_flags = list(self.flag_collection.find())
        all_flags.sort(key=lambda x: x['flagID'], reverse=True)
        
        # set initial flagID to 1 if no flag document is present
        latest_flag = all_flags[0] if all_flags else None
        if latest_flag:
            flagID = int(latest_flag['flagID']) + 1
        else:
            flagID = 1
        
        return flagID
    
    def getFlagByID(self, id):

        flag = self.flag_collection.find_one({'flagID': id})
        if flag:
            return flag
        else:
            None

    def setFlagName(self, flag_id, name):
        try: 
            self.flag_collection.update_one(
                {'flagID': flag_id},
                { '$set': { 'flagName': name } }
            )
        except InvalidId:
            return False
        return True
    
    def getFlagName(self, flag_id):
        name = self.flag_collection.find_one({'flagID': flag_id})
        if name:
            return name.get('flagName')
        else:
            return None
    
    def setFlagDesc(self, flag_id, desc):
        try: 
            self.flag_collection.update_one(
                {'flagID': flag_id},
                { '$set': { 'flagDesc': desc } }
            )
        except InvalidId:
            return False
        return True
    
    def getFlagDesc(self, flag_id):
        desc = self.flag_collection.find_one({'flagID': flag_id})
        if desc:
            return desc.get('flagDesc')
        else:
            return None
