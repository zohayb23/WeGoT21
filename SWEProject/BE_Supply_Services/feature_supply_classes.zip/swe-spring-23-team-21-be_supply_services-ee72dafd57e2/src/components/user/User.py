from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
import certifi
import bcrypt
from bson.objectid import ObjectId
from bson.errors import InvalidId

class User:
    def __init__(self, mongo_url, mongo_db):
        self.client = MongoClient(mongo_url)
        self.db = self.client[mongo_db]
        self.users = self.db['credentials']
        self.users.create_index([('id', 1)], unique=True)
        self.users.create_index([('username', 1)], unique=True)

    def create_user(self, username, password):
        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        user = { "id": str(ObjectId()), "username": username, "password": hashed }
        
        try:
            self.users.insert_one(user)
        except DuplicateKeyError:
            return False
        return True

    def reset_password(self, id, new_password):
        hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        try:
            self.users.update_one({'id': id}, {'$set': {'password': hashed_password}})
        except InvalidId:
            return False
        return True

    def validate_user(self, username, password):
        user = self.get_user(username)
        if user and bcrypt.checkpw(password.encode('utf-8'), user['password']):
            return True
        return False

    def get_user(self, username):
        user = self.users.find_one({ "username": username })
        return user

    def login_user(self, username, password):
        if self.validate_user(username, password):
            return True
        return False

    def logout_user(self):
        return True