from flask import Flask, jsonify, request
import pymongo
# import certifi

app = Flask(__name__)

# Endpoint to store location data for vehicle heartbeat
@app.route('/location', methods=['POST'])
def store_location():

    # MongoDB database connection parameters
    client = pymongo.MongoClient(
        'mongodb+srv://jklipple:tracker10@playground.fh6yrog.mongodb.net/?retryWrites=true&w=majority')
    db = client['WeGo']
    location_data = db['location_data']

    # Get the location data from the request
    data = request.get_json()
    vehicle_id = data.get('vehicle_id')
    eta = data.get('eta')
    geo_lat = data.get('geo_lat')
    geo_long = data.get('geo_long')
    route = data.get('route')
    on_route = data.get('on_route')
    status = data.get('status')

    # Check if a document with the same 'id' value already exists in the collection
    if location_data.find_one({'id': vehicle_id}):
        # If a document with the same 'id' value exists, update the document with the new location data
        location_data.update_one(
            {'_id': vehicle_id},
            {'$set': {'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long, 'route': route, 'on_route': on_route, 'status': status}}
        )
    else:
        # If a document with the same 'id' value does not exist, insert a new document with the location data
        location_data.insert_one({
            'id': vehicle_id,
            'eta': eta,
            'geo_lat': geo_lat,
            'geo_long': geo_long,
            'route': route,
            'on_route': on_route,
            'status': status
        })

    return jsonify({'message': 'Location data stored successfully.'})


# Endpoint to retrieve find the first available vehicle


@app.route('/vehicle', methods=['GET'])
def find_available_vehicle():

    # Retrieve the first available vehicle from the collection
    vehicle_data = location_data.find_one({'status': 'available'}, sort=[
                                          ('eta', pymongo.ASCENDING)])

    # Return vehicle id to demand side
    vehicle_id = vehicle_data['vehicle_id']
    eta = vehicle_data['eta']
    geo_lat = vehicle_data['geo_lat']
    geo_long = vehicle_data['geo_long']
    route = vehicle_data['route']
    on_route = vehicle_data['on_route']
    status = vehicle_data['status']

    return jsonify({'vehicle_id': vehicle_id, 'eta': eta, 'geo_lat': geo_lat, 'geo_long': geo_long, 'route': route, 'on_route': on_route, 'status': status})


if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
