from User import User

# mongo_uri = 'mongodb+srv://jklipple:tracker10@playground.fh6yrog.mongodb.net/?retryWrites=true&w=majority'
mongo_db = 'flask_db'
mongo_uri = 'mongodb://Admin:Bonjour@104.236.192.183:27017/'
user = User(mongo_uri, mongo_db)

# 104.236.192.183

# create a new user
if(user.create_user('randomaccount567', 'password123')):
    print('User created')
else:
    print('User creation failed')

# # authenticate and log in a user
# if user.login_user('jasonk_506', 'password123'):
#     print('Login successful')
# else:
#     print('Login failed')

# # reset a user's password
# user.reset_password('john_doe', 'new_password123')