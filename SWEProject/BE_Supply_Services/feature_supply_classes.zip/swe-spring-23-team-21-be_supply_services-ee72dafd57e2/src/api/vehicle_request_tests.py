import unittest
from flask import Flask
from flask.testing import FlaskClient
from unittest.mock import patch
from vehicleRequest import app

class FlaskAppTestCase(unittest.TestCase):

    def setUp(self):
        self.client = app.test_client()

    def test_render_webpage(self):
        response = self.client.get('/request_vehicle')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'<!DOCTYPE html>', response.data)

    def test_handle_request(self):
        response = self.client.post('/request', data={'dropoff_location': 'Some Destination'})
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'vehicle_id', response.data)
        self.assertIn(b'eta', response.data)
        self.assertIn(b'geo_location', response.data)
        self.assertIn(b'route', response.data)
        self.assertIn(b'on_route', response.data)
        self.assertIn(b'dropoff_location', response.data)
        self.assertIn(b'order_id', response.data)

    def test_handle_request_exception(self):
        # Mock the requests.get() method to raise an exception
        def mock_get(url):
            raise Exception('Failed to get vehicle data.')

        with patch('requests.get', side_effect=mock_get):
            response = self.client.post('/request', data={'destination_location': 'Some Destination'})
            self.assertEqual(response.status_code, 500)
            self.assertIn(b'error', response.data)

if __name__ == '__main__':
    unittest.main()
