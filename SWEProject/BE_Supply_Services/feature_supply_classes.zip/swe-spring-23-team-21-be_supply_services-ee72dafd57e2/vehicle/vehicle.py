from pymongo import MongoClient
from pymongo.errors import DuplicateKeyError
from bson.errors import InvalidId
from flag.flag import Flag

flag = Flag()

# Vehicle class with Setters and Getters for all recording attributes
class Vehicle:

    def __init__(self):
        self.client = MongoClient('mongodb://gerardo:cosc3339PASS@104.236.192.183:27017/WeGoSupply')
        self.vehicle_collection = self.client['WeGoSupply']['vehicles']
        self.fleet_collection = self.client['WeGoSupply']['fleets']
        self.flag_collection = self.client['WeGoSupply']['flags']

    def createVehicle(self, vehicleID, status, long, lat, size, desc, VIN, plates, fleet, flags):
        create_vehicle = {'vehicleID': vehicleID, 'vehicleStatus': status, 'vehicleLong': long, 'vehicleLat': lat,'vehicleSize': size, 
                          'vehicleDesc': desc, 'vehicleVIN': VIN, 'vehiclePlates': plates, 'fleetID': fleet, 'flagID': flags }
        try:
            self.vehicle_collection.insert_one(create_vehicle)
        except DuplicateKeyError:
            return False
        return True
    
    def getLatestVehicleID(self):
        all_vehicles = list(self.vehicle_collection.find())
        all_vehicles.sort(key=lambda x: x['vehicleID'], reverse=True)
        
        # Retrieve the latest managerID from the sorted list
        latest_vehicle = all_vehicles[0] if all_vehicles else None
        if latest_vehicle:
            vehicleID = int(latest_vehicle['vehicleID']) + 1
        else:
            vehicleID = 1

        return vehicleID
    
    def getVehicleByID(self, id):

        vehicle = self.vehicle_collection.find_one({'vehicleID': id})
        if vehicle:
            return vehicle
        else:
            None

    def setVehicleStatus(self, id, status):

        try:
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleStatus': status } }
            )   
        except InvalidId:
            return False
        return True
    
    def getVehicleStatus(self, id):
    
        status = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleStatus': 1})
        if status:
            return status['vehicleStatus']
        else:
            return None

    def setVehicleLong(self, id, long):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleLong': long } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehicleLong(self, id):
    
        vehicle = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleLong': 1})
        if vehicle:
            return vehicle['vehicleLong']
        else:
            return None
    
    def setVehicleLat(self, id, lat):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleLat': lat } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehicleLat(self, id):
    
        lat = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleLat': 1})
        if lat:
            return lat['vehicleLat']
        else:
            return None
    
    def setVehicleSize(self, id, size):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleSize': size } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehicleSize(self, id):
   
        size = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleSize': 1})
        if size:
            return size['vehicleSize']
        else:
            return None

    def setVehicleDesc(self, id, desc):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleDesc': desc } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehicleDesc(self, id):
    
        desc = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleDesc': 1})
        if desc:
            return desc['vehicleDesc']
        else:
            return None
    
    def setVehicleVIN(self, id, VIN):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehicleVIN': VIN } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehicleVIN(self, id):
   
        VIN = self.vehicle_collection.find_one({'vehicleID': id}, {'vehicleVIN': 1})
        if VIN:
            return VIN['vehicleVIN']
        else:
            return None
    
    def setVehiclePlates(self, id, plates):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'vehiclePlates': plates } }
            )
        except InvalidId:
            return False
        return True
    
    def getVehiclePlates(self, id):
    
        plates = self.vehicle_collection.find_one({'vehicleID': id}, {'vehiclePlates': 1})
        if plates:
            return plates['vehiclePlates']
        else:
            return None

    def setFleetID(self, id, fleetID):

        try:  
            self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$set': { 'fleetID': fleetID } }
            )
        except InvalidId:
            return False
        return True

    def getFleetByID(self, id):
        fleet = self.fleet_collection.find_one({'fleetID': id})
        if fleet:
            fleet_vehicles = self.vehicle_collection.find({'fleetID': id})
            return list(fleet_vehicles)
        else:
            return None

    def getVehicleFlags(self, id):
        # Find the vehicle document based on the vehicleID
        vehicle = self.vehicle_collection.find_one({'vehicleID': id})
        if vehicle:
            # Extract the flagIDs field from the vehicle document
            flag_ids = vehicle.get('flagIDs', [])
            return flag_ids
        else:
            []

    def addFlagID(self, id, flagID):
        try:
            vehicle = self.vehicle_collection.find_one({'vehicleID': id})
            if vehicle is None:
                return False
            existing_flags = vehicle.get('flagID', [])
            if flagID == 1:
                existing_flags = [f for f in existing_flags if f != 1]
                existing_flags.append(flagID)
            else:
                existing_flags.append(flagID)
            result = self.vehicle_collection.update_one(
                {'vehicleID': id},
                {'$set': {'flagID': existing_flags}}
            )
            if result.matched_count == 0:
                return False
            else:
                print(f"Flag {flagID} added to vehicle {id}.")
        except InvalidId:
            return False
        return True

    def removeFlag(self, id, flagID):
        try:  
            result = self.vehicle_collection.update_one(
                {'vehicleID': id},
                { '$pull': { 'flagID': flagID } }
            )
            if result.modified_count == 0:
                return False
            else:
                # Check if all flags are removed and set flagID to 1
                updated_doc = self.vehicle_collection.find_one({'vehicleID': id})
                if not updated_doc['flagID']:
                    self.vehicle_collection.update_one(
                        {'vehicleID': id},
                        { '$set': { 'flagID': [1] } }
                    )
        except InvalidId:
            return False
        return True

    def getFlagInfo(self, flag_ids):
        flags = []
        for flag_id in flag_ids:
            flag_obj = flag.getFlagByID(flag_id) # Use a different variable for the individual flag object
            if flag_obj:
                flags.append(flag_obj) # Append the individual flag object to the flags list
        return flags

    def deleteVehicle(self, id):

        try:
            self.vehicle_collection.delete_one({'vehicleID': id})
        except InvalidId:
            return False
        return True

    def getAllVehicles(self):
        vehicles = self.vehicle_collection.find()

        if vehicles:
            return list(vehicles)
        else:
            None

    def get_vehicle_with_flags(self):

        vehicles_with_flags = []
        for vehicle in self.vehicle_collection.find():
            flag_ids = vehicle.get('flagID')
            if flag_ids is None:
                vehicles_with_flags.append(vehicle)
            elif 1 not in flag_ids:
                flags = []
                for flag_id in flag_ids:
                    flag = self.flag_collection.find_one({'flagID': flag_id})
                    flags.append(flag)
                vehicle['flags'] = flags
                vehicles_with_flags.append(vehicle)

        return vehicles_with_flags