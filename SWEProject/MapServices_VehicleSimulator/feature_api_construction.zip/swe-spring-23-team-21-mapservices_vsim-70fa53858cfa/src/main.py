import threading
from vehicle_simulator import VehicleSimulator
import sys

def main():
    # Initialize VehicleSimulator instances for three vehicles
    vehicle1 = VehicleSimulator(vehicle_id=1)
    # vehicle2 = VehicleSimulator(vehicle_id=2)
    # vehicle3 = VehicleSimulator(vehicle_id=3)

    # Set pickup and destination locations for each vehicle
    vehicle1.update_pickup_location("111 Tristans Way, Buda, TX 78610")
    vehicle1.update_destination_location("Kyle, TX")
    # vehicle2.update_pickup_location("Dallas, TX")
    # vehicle2.update_destination_location("San Antonio, TX")
    # vehicle3.update_pickup_location("El Paso, TX")
    # vehicle3.update_destination_location("Fort Worth, TX")

    # Get the routes for each vehicle
    vehicle1.get_route()
    # vehicle2.get_route()
    # vehicle3.get_route()

    # Create a list of VehicleSimulator instances and start a new thread for each one
    vehicles = [vehicle1]
    threads = []
    print(vehicle1.getVehicleLocation())
    for vehicle in vehicles:
        thread = threading.Thread(target=vehicle.travel_route)
        thread.start()
        threads.append(thread)

    # Wait for all threads to complete
    for thread in threads:
        thread.join()

if __name__ == "__main__":
    main()
