from flask import Flask, jsonify, render_template, request, session
import vehicle_simulator
from threading import Thread

#Creating a Flask app object and setting its secret key
app = Flask(__name__)
app.secret_key = 'changeme'

#Creating a vehicle simulator object with vehicle_id as 1 FOR MVP DEMO PURPOSE
vehicle1 = vehicle_simulator.VehicleSimulator(vehicle_id=1)

#Actuaal function to create a new vehicle simulator object (here set with vehicle_id as 1)
def setVehicle():
    vehicle1 = vehicle_simulator.VehicleSimulator(vehicle_id=1)
    return vehicle1

#Starts the vehicle travel simulation in a new thread
def run_func():
    t1 = Thread(target=vehicle1.travel_origin_to_pickup())
    t1.start()
    return t1

#displays route between the pickup (origin) and dropoff (destination)
@app.route('/mapRoute', methods=['GET','POST'])
def mapRoute():
    if request.method == "GET":
        route = session['routeURL']
        origin = session['origin']
        dest = session['destination']
        data = {'Route' : route, 'origin' : origin, 'destination' : dest}
        if route:
            return render_template('mapRoute.html', origin=origin, destination = dest )
        return jsonify({'error' : 'Missing data!'})
    return render_template('mapRoute.html')

#Allows for the vehicle simulator to start a new thread, redirects to vSimDisplayProcessing
@app.route('/vSimDisplay')
def vSimDisplay():
    dest = session['destination']
    origin = session['origin']
    vehicleOrigin = 'Kyle, TX'
    vehicle1.update_destination_location(vehicleOrigin)
    vehicle1.update_pickup_location(origin)
    vehicle1.get_route()
    run_func()
    return render_template("vSimDisplayProcessing.html",  origin=origin, destination = dest)

#Displays vSim travelling along route
@app.route('/vSimDisplayProcessing', methods=['GET','POST'])
def vSimDisplayProcessing():
    dest = session['destination']
    origin = session['origin']
    if request.method == "GET":
        vehicleCoord = vehicle1.getVehicleLocation()
        lat = vehicleCoord[0]
        long = vehicleCoord[1]
        print(f'Vehicle={vehicleCoord}')
        return render_template('vSimDisplayProcessing.html',  origin=origin, destination = dest, vehicleCoord= vehicleCoord, lat = lat, long = long)
    return render_template('vSimDisplayProcessing.html',   origin=origin, destination = dest, vehicleCoord= vehicleCoord)


#Pages that allows users to set the origin and destination addresses
@app.route('/setAddresses', methods=['GET','POST'])
def setAddresses():
    if request.method == "POST":
        route = request.form['route']
        origin = request.form['origin']
        dest = request.form['end']
        session['routeURL'] = route
        session['origin'] = origin
        session['destination'] = dest
        print(session)
        if route:
            return jsonify({'output':'Origin and destination successfully sent'})
        return jsonify({'error' : 'Missing data!'})
    return render_template('setAddresses.html')


if __name__ == '__main__':
    vehicle1 = setVehicle()
    app.run(debug=False)