import requests

class DestinationService:
    def __init__(self, api_key):
         # Retrieving the API key
        self.api_key = api_key

    # Constructing the URL for MapQuest API using the origin and destination coordinates
    def get_route(self, origin, destination):
        # Constructing the URL for MapQuest API using the origin and destination coordinates
        url = f"http://www.mapquestapi.com/directions/v2/route?key={self.api_key}&from={origin[0]},{origin[1]}&to={destination[0]},{destination[1]}"
        
        # Sending a GET request to the API
        response = requests.get(url)

        # Checking if the API call was successful
        if response.status_code == 200:
            # Parsing the response JSON and extracting the route information
            data = response.json()
            route = data.get("route")
            return route
        else:
            return None
