//Map redering route:
window.onload = function() {
  //Gets the mapkey ASYNCHRONOUSLY! So call to mapQuest must be inside $.get('/api/mapquest_key'
  $.get('/api/mapquest_key', function(data) {
    var mapquestKey = data.key;
    L.mapquest.key = mapquestKey;

    //Renders map
    var map = L.mapquest.map('map', {
        center: [30.2672, -97.7431],
        layers: L.mapquest.tileLayer('map'),
        zoom: 20
      });
    });
}

