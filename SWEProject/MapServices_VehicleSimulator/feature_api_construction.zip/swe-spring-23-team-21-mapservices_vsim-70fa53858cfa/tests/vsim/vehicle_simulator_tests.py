import unittest
from vehicle_simulator import VehicleSimulator
from mapquest import MapQuestAPI

class TestVehicleSimulator(unittest.TestCase):
    def setUp(self):
        self.vehicle_simulator = VehicleSimulator(1)

    def test_init(self):
        self.assertEqual(self.vehicle_simulator.vehicle_id, 1)
        self.assertIsInstance(self.vehicle_simulator.mapquest_api, MapQuestAPI)
        self.assertEqual(self.vehicle_simulator.vehicle_location, self.vehicle_simulator.vehicle_origin)
        self.assertIsNone(self.vehicle_simulator.pickup_location)
        self.assertIsNone(self.vehicle_simulator.destination_location)
        self.assertIsNone(self.vehicle_simulator.route)

    def test_update_pickup_location(self):
        self.assertRaises(ValueError, self.vehicle_simulator.update_pickup_location)
        self.vehicle_simulator.update_pickup_location("New York City")
        self.assertIsInstance(self.vehicle_simulator.pickup_location, tuple)
        self.assertEqual(len(self.vehicle_simulator.pickup_location), 2)

    def test_update_destination_location(self):
        self.assertRaises(ValueError, self.vehicle_simulator.update_destination_location)
        self.vehicle_simulator.update_destination_location("Los Angeles")
        self.assertIsInstance(self.vehicle_simulator.destination_location, tuple)
        self.assertEqual(len(self.vehicle_simulator.destination_location), 2)

    def test_get_route(self):
        self.assertRaises(ValueError, self.vehicle_simulator.get_route)
        self.vehicle_simulator.update_pickup_location("New York City")
        self.vehicle_simulator.update_destination_location("Los Angeles")
        self.vehicle_simulator.get_route()
        self.assertIsInstance(self.vehicle_simulator.route, dict)
        self.assertIn("legs", self.vehicle_simulator.route)

    def test_travel_route(self):
        self.vehicle_simulator.update_pickup_location("New York City")
        self.vehicle_simulator.update_destination_location("Los Angeles")
        self.vehicle_simulator.get_route()
        self.vehicle_simulator.travel_route()
        self.assertIsNotNone(self.vehicle_simulator.route)

if __name__ == '__main__':
    unittest.main()