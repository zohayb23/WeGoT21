from mapquest import MapQuestAPI

#Simple class to convert address to geocoordinates
class Location:
    def __init__(self, address: str):
        self.mapquest_api = MapQuestAPI()
        self.address = address
        self.geocoords = self.mapquest_api.convert_address_to_mapquest_geocoords(address)

    #Function to be called to convert
    def get_geocoords(self):
        return self.geocoords
