import json
import requests
import time
import math
import threading
import os
from dotenv import load_dotenv
from mapquest import MapQuestAPI
from location import Location

load_dotenv()


class VehicleSimulator:

    def __init__(self, vehicle_id):
        # Read the API key from an environment variable
        self.api_key = os.environ.get('MAPQUEST_API_KEY')
        if not self.api_key:
            raise ValueError('API key not found')
        self.mapquest_api = MapQuestAPI()

        # Initialize class variables
        self.vehicle_id = vehicle_id
        # pass in the vehicle's origin address MAPQUEST API as Kyle, TX
        self.vehicle_origin = Location("Kyle, TX").get_geocoords()
        self.vehicle_location = self.vehicle_origin
        self.previous_location = None
        self.pickup_location = None
        self.destination_location = None
        self.route = None


        self.heartbeat_url = "http://127.0.0.1:5001/heartbeat"
        self._heartbeat()

    def _heartbeat(self):
        # Create a thread that sends heartbeats every 5 seconds
        threading.Timer(5, self._heartbeat).start()
        self.send_heartbeat()

    def send_heartbeat(self):
        # create the heartbeat JSON
        heartbeatJSON = self._create_heartbeat_json()

        # send the heartbeat
        heartbeat = requests.post(self.heartbeat_url, json=heartbeatJSON)
        return heartbeat

    def _create_heartbeat_json(self):
        #if no route, send heartbeat with route as "Not on route"
        if not self.route:
            route = "No Route"
            on_route = False
            status = "unavailable"
        else:
            route = self.get_route_streets()
            on_route = self.on_route_street(route)
            status = "available"

        heartbeatJSON = {
            "vehicle_id": self.vehicle_id,
            "geo_lat": self.vehicle_location[0],
            "geo_long": self.vehicle_location[1],
            "eta": "Test",
            "route": route,
            "on_route": on_route,
            "status": status
        }

        return heartbeatJSON

    # returns the streets of the route
    def get_route_streets(self):
        route = self.route
        street_names = []
        for leg in route['legs']:
            for maneuver in leg['maneuvers']:
                if 'streets' in maneuver:
                    street_names.append(' /'.join(maneuver['streets']))
                else:
                    street_names.append('Unknown')
        return ' /'.join(street_names)
    
    # determines if the vehicle is on the route based on the current street
    def on_route_street(self, route_streets):
        if not route_streets:
            return False

        # Get the current latitude and longitude of the vehicle
        lat, lng = self.getVehicleLocation()

        # Use MapQuest API to get the current street name
        url = f"http://www.mapquestapi.com/geocoding/v1/reverse?key={self.api_key}&location={lat},{lng}&includeRoadMetadata=true&includeNearestIntersection=true"
        response = requests.get(url)
        data = json.loads(response.text)
        current_street = data['results'][0]['locations'][0]['street']

        # Extract the street name from the current street without house number and leading digits
        current_street_words = current_street.split()
        while current_street_words and current_street_words[0].isdigit():
            current_street_words.pop(0)
        current_street_name = ' '.join(current_street_words)

        # Check if the current street name is in the route_streets list
        return current_street_name in route_streets

    def getVehicleLocation(self):
        return self.vehicle_location

    def update_pickup_location(self, pickup_location=None):
        if pickup_location is None:
            raise ValueError("Pickup location not provided")

        # check if pickup is a tuple of floats or a string that's an address
        if not isinstance(pickup_location, tuple):
            pickup_location = Location(pickup_location).get_geocoords()
            self.pickup_location = pickup_location

    def update_destination_location(self, destination_location=None):
        if destination_location is None:
            raise ValueError("destination location not provided")

        # check if destination is a tuple of floats or a string that's an address
        if not isinstance(destination_location, tuple):
            destination_location = Location(destination_location).get_geocoords()
            self.destination_location = destination_location

    # retrives the route from the vehicle's current location to the pickup location to the destination location to the vehicle's origin
    def get_route(self):
        if not self.pickup_location or not self.destination_location:
            raise ValueError(
                "pickup location and destination location must be provided")

        first_route = self.mapquest_api.get_route(self.vehicle_location, self.pickup_location)

        second_route = self.mapquest_api.get_route(self.pickup_location, self.destination_location)

        # third_route = self.mapquest_api.get_route(self.destination_location, self.vehicle_origin)

        route = None
        if first_route and second_route:
            self.route = {
                "legs": first_route["legs"] + second_route["legs"]
            }

            route = self.route

        else:
            self.route = None

        return route

    def travel_route_map(self):
        if not self.route:
            return

        legs = self.route.get("legs")
        if not legs:
            return

        for leg in legs:
            for maneuver in leg.get("maneuvers"):
                lat = maneuver.get("startPoint", {}).get("lat")
                lng = maneuver.get("startPoint", {}).get("lng")
                self.vehicle_location = (lat, lng)

                # update the previous location to the current location
                self.previous_location = self.vehicle_location

        self.map.save("vehicle_route.html")



    #  simulates the vehicle traveling along the route. notes the vehicle's location at each step, its pickup and dropoff times, its return to origin time, and its total travel time
    def travel_route(self):

        if not self.route:
            return

        legs = self.route.get("legs")
        if not legs:
            return

        total_time = 0
        pickup_flag = False
        dropoff_flag = False
        vehicle_return_flag = False
        vehicle_leave_flag = False
        for leg in legs:
            for maneuver in leg.get("maneuvers"):
                lat = maneuver.get("startPoint", {}).get("lat")
                lng = maneuver.get("startPoint", {}).get("lng")
                self.vehicle_location = (lat, lng)

                elapsed_time = maneuver.get("time")
                total_time += elapsed_time

                # convert total_time to hours minutes seconds
                hours = int(total_time / 3600)
                minutes = int((total_time % 3600) / 60)
                seconds = int(total_time % 60)

                total_time_string = f"{hours}h {minutes}m {seconds}s"

                # Check if vehicle is in same approximate location as pickup location
                if math.isclose(self.vehicle_location[0], self.pickup_location[0], abs_tol=0.0001) and math.isclose(self.vehicle_location[1], self.pickup_location[1], abs_tol=0.0001) and pickup_flag == False:
                    print(
                        f"\nVehicle ID: {self.vehicle_id} {total_time_string}s: Vehicle Location: {self.vehicle_location} <<< PICKUP")
                    pickup_flag = True

                print(
                    f"\nVehicle ID: {self.vehicle_id} {total_time_string}s: Vehicle Location: {self.vehicle_location}")

                # Check if vehicle is in same approximate location as destination location and print the total time it took to travel
                if math.isclose(self.vehicle_location[0], self.destination_location[0], abs_tol=0.0001) and math.isclose(self.vehicle_location[1], self.destination_location[1], abs_tol=0.0001) and dropoff_flag == False:
                    print(
                        f"\nVehicle ID: {self.vehicle_id} {total_time_string}s: Vehicle Location: {self.vehicle_location} <<< DROPOFF")
                    dropoff_flag = True

                # Check if vehicle is leaving its origin area
                if math.isclose(self.vehicle_location[0], self.vehicle_origin[0], abs_tol=0.0001) and math.isclose(self.vehicle_location[1], self.vehicle_origin[1], abs_tol=0.0001) and vehicle_leave_flag == False:
                    print(
                        f"\nVehicle ID: {self.vehicle_id} {total_time_string}s: Vehicle Location: {self.vehicle_location} <<< VEHICLE LEAVING ORIGIN")
                    vehicle_leave_flag = True
                
                # Check if vehicle is returning to its origin area
                if math.isclose(self.vehicle_location[0], self.vehicle_origin[0], abs_tol=0.0001) and math.isclose(self.vehicle_location[1], self.vehicle_origin[1], abs_tol=0.0001) and vehicle_return_flag == False and dropoff_flag == True:
                    print(
                        f"\nVehicle ID: {self.vehicle_id} {total_time_string}s: Vehicle Location: {self.vehicle_location} <<< VEHICLE RETURNING TO ORIGIN")
                    vehicle_return_flag = True

                time.sleep(5)

        return total_time
    
    def travel_origin_to_pickup(self):
        if not self.route:
            return
        
        legs = self.route.get("legs")
        if not legs:
            return
        
        origin_to_pickup_leg = legs[0]
        for maneuver in origin_to_pickup_leg.get("maneuvers"):
            lat = maneuver.get("startPoint", {}).get("lat")
            lng = maneuver.get("startPoint", {}).get("lng")
            self.vehicle_location = (lat, lng)

            elapsed_time = maneuver.get("time")

            # convert elapsed_time to hours minutes seconds
            hours = int(elapsed_time / 3600)
            minutes = int((elapsed_time % 3600) / 60)
            seconds = int(elapsed_time % 60)

            elapsed_time_string = f"{hours}h {minutes}m {seconds}s"

            print(f"\nVehicle ID: {self.vehicle_id} {elapsed_time_string}s: Vehicle Location: {self.vehicle_location} <<< TRAVELING TO PICKUP")
            time.sleep(8)
            
    def travel_pickup_to_destination(self):
        if not self.route:
            return
        
        legs = self.route.get("legs")
        if not legs:
            return
        
        pickup_to_destination_leg = legs[1]
        for maneuver in pickup_to_destination_leg.get("maneuvers"):
            lat = maneuver.get("startPoint", {}).get("lat")
            lng = maneuver.get("startPoint", {}).get("lng")
            self.vehicle_location = (lat, lng)

            elapsed_time = maneuver.get("time")

            # convert elapsed_time to hours minutes seconds
            hours = int(elapsed_time / 3600)
            minutes = int((elapsed_time % 3600) / 60)
            seconds = int(elapsed_time % 60)

            elapsed_time_string = f"{hours}h {minutes}m {seconds}s"

            print(f"\nVehicle ID: {self.vehicle_id} {elapsed_time_string}s: Vehicle Location: {self.vehicle_location} <<< TRAVELING TO DESTINATION")

    
