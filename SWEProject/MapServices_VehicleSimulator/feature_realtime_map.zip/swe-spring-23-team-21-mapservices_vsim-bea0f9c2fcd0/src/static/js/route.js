//Map redering route:
window.onload = function() {
    //Get api key
    $.get('/api/mapquest_key', function(data) {
        var mapquestKey = data.key;
        L.mapquest.key = mapquestKey;

        //renders map
        var map = L.mapquest.map('map', {
        center: [30.2672, -97.7431],
        layers: L.mapquest.tileLayer('map'),
        zoom: 13
    });

    //Call to Flask to get the template mapRoute
    $.ajax({
        type: "GET",
        url: '/mapRoute',
        error : function (status, statusText, responses) {
            var errormsg = "";
            errormsg += "Error. Status: " + statusText + " " + responses;
            console.log(errormsg);
        },
        success: function (data, statusText, responses) {
            var callbackresponse = responses.status;
            if (callbackresponse === 200) {
                console.log('Success')
             }  
            else  {
                console.log("API server Error");
            }
        }
    });
    });
}


//get the button into a JS object
var sendBtn = document.getElementById("form-send");
//create an event listener and handler for the send button
sendBtn.onclick = function () {
    var origin = document.getElementById("origin");
    var destination = document.getElementById("destination");
    //get all the strings in the elements and trim them
    var originStr = origin.innerHTML;
    var destinationStr = destination.innerHTML;

    //set Route options + pickUp dropOff locations
    L.mapquest.directions().route({
        start: originStr,
        end: destinationStr,
        options: {
            avoids: ['toll road']
          }     
      });
}

  
