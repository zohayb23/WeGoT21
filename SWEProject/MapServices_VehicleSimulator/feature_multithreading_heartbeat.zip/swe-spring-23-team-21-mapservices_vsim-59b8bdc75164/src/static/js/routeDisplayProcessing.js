//Map redering route:
window.onload = function() {
   //Gets the mapkey ASYNCHRONOUSLY! So call to mapQuest must be inside $.get('/api/mapquest_key'
  $.get('/api/mapquest_key', function(data) {
    var mapquestKey = data.key;
    L.mapquest.key = mapquestKey;
    travelToPickUp()
  });  
}

//Displays the route between pick up and drop off on a map
function displayRoute(originStr, destinationStr){
    
    var map = L.mapquest.map('map', {
        center: [30.2672, -97.7431],
        layers: L.mapquest.tileLayer('map'),
        zoom: 20
      });

    console.log(originStr)
    var directions = L.mapquest.directions();
    directions.setLayerOptions({
        startMarker: {
          icon: 'circle',
          iconOptions: {
            size: 'sm',
            primaryColor: '#9acd32',
            secondaryColor: '#f25918',
            symbol: 'W'
          }
        }});

    console.log(originStr, destinationStr)
    directions.route({
        start: originStr,
        end: destinationStr,
        options: {
            avoids: ['toll road']
          }     
      });  
      
      setTimeout(() => {
        location.reload()
      }, "5000")
      

}

//Starts vSim travelling
function travelToPickUp() {   
        $.ajax({
            type: "GET",
            url: '/vSimDisplayProcessing',
            async: false,
            error : function (status, statusText, responses) {
                var errormsg = "";
                errormsg += "Error. Status: " + statusText + " " + responses;
                console.log(errormsg);
            },
            success: function (data, statusText, responses) {
                var callbackresponse = responses.status;
                if (callbackresponse === 200) {
                    console.log('Success')
                 }  
                else  {
                    console.log("API server Error");
                }
            },
               
        });
        var origin = document.getElementById("origin").innerHTML;
        var destination = document.getElementById("destination").innerHTML;
        var currentlocationstr = document.getElementById("vehicleCoord").innerHTML;
        var lat = parseFloat( document.getElementById("lat").innerHTML);
        var long = parseFloat( document.getElementById("long").innerHTML);
        currentlocation = [lat, long]
        displayRoute(currentlocation, origin)

}


//get the button into a JS object
var sendBtn = document.getElementById("form-send");
//create an event listener and handler for the send button
sendBtn.onclick = function () {

}