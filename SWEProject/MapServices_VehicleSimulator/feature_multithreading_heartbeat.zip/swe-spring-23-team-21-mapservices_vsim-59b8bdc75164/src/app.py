from flask import Flask, jsonify, render_template, request, session
from pymongo import MongoClient
from flask_pymongo import PyMongo
from threading import Thread
import time

#Creating a Flask app object and setting its secret key
app = Flask(__name__)
app.secret_key = 'changeme'

#Setting up the MongoDB connection to mongoDB on remote droplet
app.config['MONGO_DBNAME'] = 'flask_db'
app.config['MONGO_USERNAME'] = 'Admin'
app.config['MONGO_PASSWORD'] = 'Bonjour'
app.config['MONGO_URI'] = 'mongodb://Admin:Bonjour@104.236.192.183:27017/flask_db'

client = MongoClient('mongodb://Admin:Bonjour@104.236.192.183:27017/')
db = client['flask_db']

#Creating a PyMongo object
mongo = PyMongo(app)

#Function to fetch heartbeat data every 5 seconds
def fetch_heartbeat_data():
    while True:
        heartbeat_data = db.location_data.find()
        # Convert ObjectId fields to strings and exclude the _id field
        heartbeat_data = [{k: v for k, v in data.items() if k != "_id"} for data in heartbeat_data]
        app.heartbeat_data = heartbeat_data
        time.sleep(5)

#Create and start the heartbeat data fetching thread
heartbeat_thread = Thread(target=fetch_heartbeat_data)
heartbeat_thread.start()

#Endpoint to store location data for vehicle heartbeat
@app.route("/heartbeat_data", methods=['GET'])
def heartbeat_data():
    heartbeat_data = app.heartbeat_data
    return render_template('heartbeat_data.html', heartbeat_data=heartbeat_data)

# Endpoint to return the latest heartbeat data as JSON
@app.route("/heartbeat_data_json", methods=["GET"])
def heartbeat_data_json():
    heartbeat_data = db.location_data.find()
    # Convert ObjectId fields to strings and exclude the _id field
    heartbeat_data = [{k: v for k, v in data.items() if k != "_id"} for data in heartbeat_data]
    return jsonify(heartbeat_data)



# #Creating a vehicle simulator object with vehicle_id as 1 FOR MVP DEMO PURPOSE
# vehicle1 = vehicle_simulator.VehicleSimulator(vehicle_id=1)

#Actuaal function to create a new vehicle simulator object (here set with vehicle_id as 1)
# def setVehicle():
#     vehicle1 = vehicle_simulator.VehicleSimulator(vehicle_id=1)
#     return vehicle1

# #Starts the vehicle travel simulation in a new thread
# def run_func():
#     t1 = Thread(target=vehicle1.travel_origin_to_pickup())
#     t1.start()
#     return t1

#displays route between the pickup (origin) and dropoff (destination)
@app.route('/mapRoute', methods=['GET','POST'])
def mapRoute():
    if request.method == "GET":
        route = session['routeURL']
        origin = session['origin']
        dest = session['destination']
        data = {'Route' : route, 'origin' : origin, 'destination' : dest}
        if route:
            return render_template('mapRoute.html', origin=origin, destination = dest )
        return jsonify({'error' : 'Missing data!'})
    return render_template('mapRoute.html')

# #Allows for the vehicle simulator to start a new thread, redirects to vSimDisplayProcessing
# @app.route('/vSimDisplay')
# def vSimDisplay():
#     dest = session['destination']
#     origin = session['origin']
#     vehicleOrigin = 'Kyle, TX'
#     vehicle1.update_destination_location(vehicleOrigin)
#     vehicle1.update_pickup_location(origin)
#     vehicle1.get_route()
#     run_func()
#     return render_template("vSimDisplayProcessing.html",  origin=origin, destination = dest)

# #Displays vSim travelling along route
# @app.route('/vSimDisplayProcessing', methods=['GET','POST'])
# def vSimDisplayProcessing():
#     dest = session['destination']
#     origin = session['origin']
#     if request.method == "GET":
#         vehicleCoord = vehicle1.getVehicleLocation()
#         lat = vehicleCoord[0]
#         long = vehicleCoord[1]
#         print(f'Vehicle={vehicleCoord}')
#         return render_template('vSimDisplayProcessing.html',  origin=origin, destination = dest, vehicleCoord= vehicleCoord, lat = lat, long = long)
#     return render_template('vSimDisplayProcessing.html',   origin=origin, destination = dest, vehicleCoord= vehicleCoord)


#Pages that allows users to set the origin and destination addresses
@app.route('/setAddresses', methods=['GET','POST'])
def setAddresses():
    if request.method == "POST":
        route = request.form['route']
        origin = request.form['origin']
        dest = request.form['end']
        session['routeURL'] = route
        session['origin'] = origin
        session['destination'] = dest
        print(session)
        if route:
            return jsonify({'output':'Origin and destination successfully sent'})
        return jsonify({'error' : 'Missing data!'})
    return render_template('setAddresses.html')


if __name__ == '__main__':
    app.run(debug=False)