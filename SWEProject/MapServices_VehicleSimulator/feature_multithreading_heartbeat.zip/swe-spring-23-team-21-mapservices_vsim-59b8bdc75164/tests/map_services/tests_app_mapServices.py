import unittest
from flask import session
from app import app, setVehicle, run_func
from unittest import mock
import sys
# specify the path to the src folder
sys.path.append('src')
from vehicle_simulator import VehicleSimulator

class TestApp(unittest.TestCase):
    vehicle1 = VehicleSimulator(vehicle_id=1)

    def setUp(self):
        self.app = app.test_client()
        self.vehicle1 = VehicleSimulator(vehicle_id=1)
        
    def test_set_addresses_post(self):
        response = self.app.post('/setAddresses', data={
            'route': 'route',
            'origin': '300 S Congress Ave Austin, TX 78704',
            'end': '3000 S Congress Ave Austin, TX 78704'
        })
        self.assertEqual(response.status_code, 200)

    def test_set_addresses_get(self):
        response = self.app.get('/setAddresses')
        self.assertEqual(response.status_code, 200)

    def test_map_route_get(self):
        with app.test_client() as client:
            with client.session_transaction() as session:
                # Modify the session in this context block.
                session['routeURL'] = 'a nice route'
                session['origin'] = '300 S Congress Ave Austin, TX 78704'
                session['destination'] = '3000 S Congress Ave Austin, TX 787'
            self.vehicle1 = setVehicle()
            # Test the request in this context block.
            res = client.get("/mapRoute")
            self.assertTrue(res is not None)

    def test_vsim_display(self):
        with app.test_client() as client:
            with client.session_transaction() as session:
            # Modify the session in this context block.
                session['routeURL'] = 'a nice route'
                session['origin'] = '300 S Congress Ave Austin, TX 78704'
                session['destination'] = '3000 S Congress Ave Austin, TX 78704'
            self.setUp()  # call setUp to define the vehicle1 object
            vehicleOrigin = self.vehicle1.getVehicleLocation()
            res = client.get("/vSimDisplay")
            self.assertEqual(res.status_code, 200)

    def test_vsim_display_processing(self):
        with app.test_client() as client:
            with client.session_transaction() as session:
            # Modify the session in this context block.
                session['routeURL'] = 'a nice route'
                session['origin'] = '300 S Congress Ave Austin, TX 78704'
                session['destination'] = '3000 S Congress Ave Austin, TX 78704'
            self.setUp()  # call setUp to define the vehicle1 object
            vehicleOrigin = self.vehicle1.getVehicleLocation()
            res = client.get("/vSimDisplayProcessing")
            self.assertEqual(res.status_code, 200)


if __name__ == '__main__':
    unittest.main()
