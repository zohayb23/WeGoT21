# Main Branch

## Purpose
The main branch represents the latest stable release of the project. Code that is on the main branch should be well-tested and ready for deployment. It is the branch that should be used for production releases.
This repository contains all MapQuest Services API and Vehicle Simulator Back End files needed for the TaaS platform project's demand & supply-side services, such as passing origin and destination addresses to MapQuest services to convert into a list of geocodes composing the route of the simulated vehicles. Multithreading capability allows the gathering of locational updates from one or more simulated vehicles at once.

---

# Features
All feature branches include MapQuest services class files for converting addresses into geocodes, test cases for map services and vehicle simulator included, and are dependent on the mapquest and vehicle_simulator classes
### API Construction
- Contains a flask app.py allowing the sending of information to simulated vehicles, and the initialization fo multiple threads to run many simulated vehicles simultaneously 
### Multithreading Heartbeat
- Contains a flask app.py that connects to a MongoDB database to continually update the simulated vehicle's location as it's traveling its route, while interacting with MapQuest services for geocodes of this data, and opening a thread to run the locational heartbeat and simulated vehicle at the same time
### Realtime Map
- Contains a flask app.py that connects to a MongoDB database and opens a thread to continually read updating location data from the vehicle heartbeat to update a map displayed on the Front End in real-time. Also features multithreading to run multiple vehicle simulator instances at once 

---

# Usage
## Before pushing commits or merging to main
- Only well-tested and stable code should be merged into the main branch.
- The main branch must be approved by the QA before any changes are made.
- Release tags should be created from the main branch to track specific releases.
- Perform the steps listed under **Integration Testing** prior to merging into the main branch
- **Refer to dev branch** for testing dimensions and benchmarks of feature branches

## Integration Testing
1. Clone the repository to your local machine following the instructions provided under **Cloning the main branch**
2. Merge branches on LOCAL repository, DO NOT PUSH the merged changes unless functionality is verified!
3. Run all unit tests for class files in the merged branch
4. Verify intended functionality: Ensure no part of the code breaks another

## Documentation
1. Back End Python files have comments describing the code
2. Comments should guide the reader towards intended functionality without them having to read through the code
3. Documentation for passing test cases is uploaded to Team 21's Google Drive

## Cloning the main branch
1. git clone [repository URL]
2. cd [repository name]
3. git checkout main
4. From there, you can work on the project, make changes, and push commits to the main branch.  However, it's important to note that code on the main branch should be stable and well-tested, so use it for production releases.

## Dependencies
### PyMongo
- This module is needed for the back end to interact with the non-relational MongoDB database

Install:
	
		python3 -m pip install pymongo
	
Imports:
	
		from pymongo import MongoClient
	
### Flask, Flask-PyMongo
- The back end uses flask app files for front end integration, it is needed to render front end templates and process user input
- The PyMongo plug-in allows the back end to interact with the non-relational MongoDB database by querying, inserting, and deleting

Install:

		python3 -m pip install flask Flask-PyMongo
	
Imports:
	
		from flask import Flask, jsonify, request, session, render_template
		from flask_pyMongo import PyMongo

---

## Contributors
- Jason Klipple (Database integration, VSIM Back End Developer, API Developer & White box Tester)
- Anne Cuzeau (MapQuest Services integration, Vehicle API Integration, & White box Tester)
