import os
import requests

from dotenv import load_dotenv

load_dotenv()

#Class to get route from MapQuest
class MapQuestAPI:
    def __init__(self):
         # Retrieving the API key
        self.api_key = os.environ.get('MAPQUEST_API_KEY')
        if not self.api_key:
            raise ValueError('API key not found')

#Given an address, retrieves the corresponding latitude and longitude using MapQuest API.
    def convert_address_to_mapquest_geocoords(self, address):
        # Constructing the URL call for MapQuest API using the address
        url = f"http://www.mapquestapi.com/geocoding/v1/address?key={self.api_key}&location={address}"

        # Sending a GET request to the API
        response = requests.get(url)

        # Checking if the API call was successful
        if response.status_code == 200:
            # Parsing the response JSON and extracting the converted latitude and longitude
            data = response.json()
            location = data.get("results")[0].get("locations")[0].get("latLng")
            return (location["lat"], location["lng"])
        else:
            return None

    #Given origin and destination coordinates, retrieves the route using MapQuest API.
    def get_route(self, from_location, to_location):
        # Constructing the location strings in the format "latitude,longitude"
        from_location_string = f"{from_location[0]},{from_location[1]}"
        to_location_string = f"{to_location[0]},{to_location[1]}"

        # Constructing the URL for MapQuest API using the location strings
        url = f"http://www.mapquestapi.com/directions/v2/route?key={self.api_key}&from={from_location_string}&to={to_location_string}"
        
        # Sending a GET request to the API
        response = requests.get(url)

        # Checking if the API call was successful
        if response.status_code == 200:
            data = response.json()
            route = data.get("route")
            # Returning the route information
            return route
        else:
            return None
