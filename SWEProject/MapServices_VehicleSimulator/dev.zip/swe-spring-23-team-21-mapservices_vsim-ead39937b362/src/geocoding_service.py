import requests

class GeocodingService:
    def __init__(self, api_key):
         # Retrieving the API key
        self.api_key = api_key

    def convert_to_mapquest_geocoords(self, location):
        # Constructing the location string in the format "latitude,longitude"
        location_string = f"{location[0]},{location[1]}"

         # Constructing the URL for MapQuest API using the location string
        url = f"http://www.mapquestapi.com/geocoding/v1/reverse?key={self.api_key}&location={location_string}"
        response = requests.get(url)

        # Checking if the API call was successful
        if response.status_code == 200:
            data = response.json()
            # Parsing the response JSON and extracting the location and converted latitude and longitude
            location = data.get("results")[0].get("locations")[0].get("latLng")
            return location["lat"], location["lng"]
        else:
            return None
