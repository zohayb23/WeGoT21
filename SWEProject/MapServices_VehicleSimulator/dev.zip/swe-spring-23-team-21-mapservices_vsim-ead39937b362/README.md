# Dev Branch

## Purpose
The dev branch is where active development takes place. This is the branch where features are added, bugs are fixed, and new code is written. It is a living branch that is constantly evolving as development work progresses.
Map Services integrated Back End and Vehicle Simulator class files, associated unit tests, and flask app files will be initially pushed to an appropriate feature branch.
Once QA has certified the passing of all white box tests, a pull request can be opened for branching code to be merged into dev.

---

# Testing Criteria
Below is a list of requirements for code to satisfy before it can move on from dev:

## Unit Tests
1. Back End code passes all White Box unit test cases
2. Unit test code coverage is at least 80%
3. Test cases cover interactions between items from different branches, rather than each piece individually

## How to Test
1. Follow the instructions under **Copy code** in the **Usage** section to clone the repository to your local machine
2. Checkout the feature branch for the code you intend to test
3. Open the code file and its unit test file in VS Code (or similar Python IDE)
4. If it is not already installed, install the Coverage module to gather unit test code coverage metrics
Install with:
		
		python3 -m pip install coverage

5. In the terminal, execute the following commands:

		coverage run [filename.py]
		coverage report -m

This will report the coverage metrics, ensure coverage is at least 80%

---

# Features
All feature branches include MapQuest services class files for converting addresses into geocodes, test cases for map services and vehicle simulator included, and are dependent on the mapquest and vehicle_simulator classes
### API Construction
- Contains a flask app.py allowing the sending of information to simulated vehicles, and the initialization fo multiple threads to run many vehicles simultaneously, as well as 
### Multithreading Heartbeat
- Contains a flask app.py that connects to a MongoDB database to continually update the simulated vehicle's location as it's traveling its route, while interacting with MapQuest services for geocodes of this data, and opening a thread to run the locational heartbeat and simulated vehicle at the same time
### Realtime Map
- Contains a flask app.py that connects to a MongoDB database and opens a thread to continually read updating location data from the vehicle heartbeat to update a map displayed on the Front End in real-time. Also features multithreading to run multiple vehicle simulator instances at once 

---

# Usage
To use the dev branch, clone the repository and switch to the dev branch using the following commands:

## Copy code
1. git clone [repository URL]
2. cd [repository name]
3. git checkout dev
4. From there, you can work on the project, make changes, and push commits to the dev branch. However, it's important to note that code on the dev branch may be in an unstable or unfinished state, so use it at your own risk.

## Merging into Dev
Before merging code into the dev branch, create a feature branch and open a pull request so that other team members can review the changes.
You must be passing all tests sent to you by the QA before pushing to the dev branch.
Please avoid pushing directly to the dev branch unless you have a very good reason to do so.
The dev branch is often used as the basis for creating release branches or tags, so it's important to keep it in good shape.

---

## Contributors
- Jason Klipple (Database integration, VSIM Back End Developer, API Developer & White box Tester)
- Anne Cuzeau (MapQuest Services integration, Vehicle API Integration, & White box Tester)
