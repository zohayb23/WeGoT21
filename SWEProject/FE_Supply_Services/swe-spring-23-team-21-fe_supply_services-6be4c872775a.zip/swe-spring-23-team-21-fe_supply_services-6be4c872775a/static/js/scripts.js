function validateUser(event){
    event.preventDefault();
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    if (username == "Fleet" && password == "Fleet"){
        alert("Login successfully");
        window.location.href = "Dashboard.html"; // Redirecting to other page.
        return false;
    }
    else{
        alert("Invalid Username or Password");
        return false;
    }


} 

function displayVehicleList(){

}

function displayVehicleMap(){
    window.location.href = "VehicleMap.html"; // Redirecting to other page.
    
    return false;
}
