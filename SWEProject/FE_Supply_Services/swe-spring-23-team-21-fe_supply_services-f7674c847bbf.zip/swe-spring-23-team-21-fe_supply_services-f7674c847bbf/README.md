# Main Branch

## Purpose
The main branch represents the latest stable release of the project. Code that is on the main branch should be well-tested and ready for deployment. It is the branch that should be used for production releases.
This repository holds the front end files needed for the TaaS platform project's supply services, such as login, view fleets, vehicles and flags for the Fleet Manager. It features a dashboard, as well as pages for adding fleets and vehicles.

---
# Features
### Webskeleton
- Contains all the HTML and CSS files that make up the front end of the Fleet Manager web app, such as the login page, create account, Fleet Manager dashboard, view fleets, vehicles, flags, and more
### Selenium Black & Grey Box Test Cases
- Contains a singular .side file with Black box and Grey box test suites populated with corresponding test cases

---

# Usage
## Before pushing commits or merging to main
- Only well-tested and stable code should be merged into the main branch.
- The main branch must be approved by the QA before any changes are made.
- Release tags should be created from the main branch to track specific releases.
- Perform the steps listed under **Integration Testing** prior to merging into the main branch
- **Refer to dev branch** for testing dimensions and benchmarks of feature branches

## Integration Testing
1. Ensure code files to be hosted on the Supply server (URL: https://swesupply2023team21.xyz) **Consult DevOps**
2. Checkout the tests/Selenium branch, instructions under **Cloning the main branch**, replace "main" with "tests/Selenium" in step 3
3. Merge branches on LOCAL repository, DO NOT PUSH the merged changes unless functionality is verified!
4. Open Selenium IDE and open the .side file: Installation instructions can be found on this document: https://docs.google.com/document/d/1m1akPApR7YYkAZjKoTchr6cHnMGQD6SwRv2R7INnwyU/edit?usp=share_link
5. Run all Selenium tests for the Front End, monitor the execution
6. Verify intended functionality: Ensure all page links and functions perform the intended action as well as the passing of all test cases

## Documentation
1. Front End HTML files have comments describing the code
2. Comments should guide the reader towards intended functionality without them having to read through the code
3. Documentation for passing test cases is uploaded to Team 21's Google Drive

## Cloning the main branch
To use the main branch, clone the repository and switch to the main branch using the following commands:

- git clone [repository URL]
- cd [repository name]
- git checkout main
- From there, you can work on the project, make changes, and push commits to the main branch. However, it's important to note that code on the main branch should be stable and well-tested, so use it for production releases.

---

# Known Delays
Currently known delays and reasonings are listed below:
### Make Payment Page
- Payment services integration is out of the scope for the PoC release, it may be added as the project continues

---

## Contributors
- Eric Rodriguez (Front End Developer)
- Kayla Harris (Front End Developer)
- Jacob Dominguez (QA Black & Grey box Tester)
