from flask import Flask, render_template, request, session, redirect, url_for, jsonify
import os
import requests
import json
from dotenv import dotenv_values
from datetime import datetime
from user import User
from flask_cors import CORS

from dotenv import load_dotenv

app = Flask(__name__, template_folder="templates")
env_vars = dotenv_values(".env")
app.secret_key = env_vars.get("SECRET_KEY")
CORS(app)

load_dotenv()

# Create a User object with the required parameters
user = User()

@app.route("/")
def index():
    return render_template("login.html")

@app.route("/login", methods=["POST", "GET"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if username == None:
        return render_template("login.html", error="")
    
    if user.login_user(username, password):
        session["username"] = username
        return render_template("dashboard.html", username=session["username"])
    else:
        return render_template("login.html", error="Username and/or password incorrect")

@app.route("/dashboard")
def dashboard():
    if session.get("username"):
        return render_template("dashboard.html", username=session["username"])
    return redirect(url_for("login"))

#Logout user
@app.route("/logout", methods=["POST", "GET"])
def logout():
    #remove orderID and username from session
    session.pop("orderId", None)
    session.pop("username", None)
    return render_template("login.html")


if __name__ == "__main__":
    app.run(host='0.0.0.0')
