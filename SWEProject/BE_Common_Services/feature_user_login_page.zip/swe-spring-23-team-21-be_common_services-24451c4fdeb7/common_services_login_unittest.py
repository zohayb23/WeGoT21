from flask import Flask, render_template, request, session, redirect, url_for, jsonify
import requests
import unittest
from unittest.mock import patch
from datetime import datetime
from demandWeGo import app
import random

class TestFlaskApp(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        app.config['TESTING'] = True

    def test_login_successful(self):
        with patch('demandWeGo.user.login_user', return_value=True):
            response = self.client.post('/login', data=dict(
                username="test",
                password="test123"
            ), follow_redirects=True)
            self.assertEqual(response.status_code, 200)

    def test_login_unsuccessful(self):
        with patch('demandWeGo.user.login_user', return_value=False):
            response = self.client.post('/login', data=dict(
                username="testuser",
                password="wrongpassword"
            ), follow_redirects=True)
            self.assertEqual(response.status_code, 200)
            
if __name__ == '__main__':
    unittest.main()
