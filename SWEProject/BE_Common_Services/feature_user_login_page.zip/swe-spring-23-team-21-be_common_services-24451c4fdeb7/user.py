import certifi
import bcrypt
import os
import random
from dotenv import dotenv_values
from datetime import datetime
import mysql.connector

class User:
    def __init__(self):
        # Gets the DB logins
        env_vars = dotenv_values(".env")
        self._username = env_vars.get("USERNAME")
        self._pwd = env_vars.get("PWD")

    def validate_user(self, username, password):
        try:
            # Retrieve the hashed and salted password from the SQL database
            connection = mysql.connector.connect(user=self._username, password=self._pwd, host='104.236.2.101', database='WeGo', port='3306')
            cursor = connection.cursor()
            query = "SELECT password FROM User WHERE username = %s"
            cursor.execute(query, (username,))
            row = cursor.fetchone()

            if row is not None:
                # If the row exists, check if the provided password matches the stored hash
                try:
                    hashed_password = row[0]
                    if bcrypt.checkpw(password.encode('utf-8'), str(hashed_password).encode('utf-8')):
                        # If the password matches, return True to indicate success
                        cursor.close()
                        connection.close()
                        return True
                    else:
                        # If the password doesn't match, return False to indicate failure
                        cursor.close()
                        connection.close()
                        return False
                except ValueError:
                    # If the stored hash is invalid, return False to indicate failure
                    cursor.close()
                    connection.close()
                    return False
            else:
                # If no row was found, return False to indicate failure
                cursor.close()
                connection.close()
                return False

        except mysql.connector.Error as e:
            print("Unable to connect to the database:", e)
            # Return False to indicate failure
            return False


    def user_already_exists(self, username):
        # Check if the username already exists
        connection = mysql.connector.connect(user=self._username, password=self._pwd,host='104.236.2.101', database='WeGo', port='3306')
        cursor = connection.cursor()
        query = "SELECT password FROM User WHERE username = %s"
        cursor.execute(query, (username,))
        result = cursor.fetchone()
        if result:
            return True
        else:
            return False
        
    def login_user(self, username, password):
        if self.validate_user(username, password):
            return True
        return False

    def logout_user(self):
        return True