/* NOTE: IF ANY QUESTIONS: CONTACT ANNE (author of FE validation) */

function validEmail(email) {
    /* Regex to valid email on front end */
    /* do not modify this fucntion, use it as is */
    var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}

function clearForm() {
    /*
     * this function replaces the text in text boxes with empty strings
     * and replaces the message area with an html <br>
     */
    document.getElementById("username").value = "";
    document.getElementById("password").value = "";
}


function validate() {
    var errorMessage = "";

    //get all the elements into the function
    var nameInput = document.getElementById("username");
    var pwdInput = document.getElementById("password");

    //get all the strings in the elements and trim them
    var name = nameInput.value.trim();
    var pwd = pwdInput.value.trim();

    //put the trimmed versions back into the form for good UX
    nameInput.value = name;
    pwdInput.value = pwd;
   
    //test the strings from the form and store errors
    if (name === "") {
        errorMessage += "Username/Email field cannot be empty.<br>";
    }
	
    /* Call email validation function and assign T/F to variable emailflag*/
    var emailflag1 = validEmail(name);
	
    if ((emailflag1 === false)) {
        errorMessage += "Not a valid email address.<br>";
	}
	
    if (pwd === "") {
        errorMessage += "Password field cannot be empty.<br>";
    }
	
    //send the errors back or send an empty string if there is no error
    return errorMessage;

}

//get the button into a JS object
var sendBtn = document.getElementById("form-send");
//create an event listener and handler for the send button
sendBtn.onclick = function () {
    //bring the message area in in-case we need it to report errors
    var msgArea = document.getElementById("msg");
    //get the validation of the form
    var msg = validate();
    //report errors or submit the form
    console.log(msg)
    if (msg === "") {
        clearForm();
        msgArea.innerHTML = "Redirecting...";
    } else {
        msgArea.innerHTML = msg;
    }

};