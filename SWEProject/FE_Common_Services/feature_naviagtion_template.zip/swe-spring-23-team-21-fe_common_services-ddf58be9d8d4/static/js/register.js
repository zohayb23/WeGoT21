const form = document.querySelector('form');
const emailInput = document.querySelector('#email');
const passwordInput = document.querySelector('#password');
const confirmPasswordInput = document.querySelector('#confirm-password');
const usernameInput = document.querySelector('#username');
const phoneNumberInput = document.querySelector('#phone');
const servicesDiv = document.querySelector('#servicesDiv');
const formInputGroup = document.querySelector('#form--input-group');


form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (!validateEmail(emailInput.value)) {
    alert('Please enter a valid email address.');
    return;
  }
  if (!validatePassword(passwordInput.value)) {
    alert('Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number.');
    return;
  }
  if (passwordInput.value !== confirmPasswordInput.value) {
    alert('Passwords do not match.');
    return;
  }
  
  if (!validateUsername(usernameInput.value)) {
    alert('Username must be at least 3 characters long and contain only letters, numbers, underscores, or hyphens.');
    return;
  }
  if (!validatePhoneNumber(phoneNumberInput.value)) {
    alert('Please enter a valid phone number in the format XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX.');
    return;
  }
  if(!validateServiceChecked()){
    alert('Please select at least one Service');
    event.preventDefault();
  }
});


// Validations
function validateEmail(email) {
  // Regular expression for email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePassword(password) {
  // Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, and one number
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;
  return passwordRegex.test(password);
}

function validateUsername(username) {
    // Username must be at least 3 characters long and contain only letters, numbers, underscores, or hyphens
    const usernameRegex = /^[a-zA-Z0-9_-]{3,}$/;
    return usernameRegex.test(username);
  }

function validatePhoneNumber(phoneNumber) {
    // Phone number must be in the format XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX
    const phoneNumberRegex = /^\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/;
    return phoneNumberRegex.test(phoneNumber);
}

function validateServiceChecked() {
  // Get services data
  const service1 = document.getElementById("service1").checked;
  const service2 = document.getElementById("service2").checked;
  const service3 = document.getElementById("service3").checked;

  // Check if at least one service is checked
  if (!service1 && !service2 && !service3) {
    return false;
  }
  return true;
}

// Displays services checkbox options on "next" btn click
function showServices() {
    // Show the services div
    document.getElementById("servicesDiv").style.display = "block";
    document.getElementById("form--input-group").style.display = "none";
  }
  