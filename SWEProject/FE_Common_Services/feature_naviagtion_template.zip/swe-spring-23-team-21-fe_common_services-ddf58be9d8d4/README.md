## Dev Branch
Purpose
The dev branch is where active development takes place. This is the branch where features are added, bugs are fixed, and new code is written. It is a living branch that is constantly evolving as development work progresses.

## How to use
To use the dev branch, clone the repository and switch to the dev branch using the following commands:


## Copy code
1. git clone [repository URL]
2. cd [repository name]
3. git checkout dev
4. From there, you can work on the project, make changes, and push commits to the dev branch. However, it's important to note that code on the dev branch may be in an unstable or unfinished state, so use it at your own risk.

---

**Other relevant information
Before merging code into the dev branch, create a feature branch and open a pull request so that other team members can review the changes.
You must be passing all tests sent to you by the QA before pushing to the dev branch.
Please avoid pushing directly to the dev branch unless you have a very good reason to do so.
The dev branch is often used as the basis for creating release branches or tags, so it's important to keep it in good shape.

**Edit a file, create a new file, and clone from Bitbucket in under 2 minutes**

When you're done, you can delete the content in this README and update the file with details for others getting started with your repository.

*We recommend that you open this README in another tab as you perform the tasks below. You can [watch our video](https://youtu.be/0ocf7u76WSo) for a full demo of all the steps in this tutorial. Open the video in a new tab to avoid leaving Bitbucket.*

---

## Clone a repository

Use these steps to clone from SourceTree, our client for using the repository command-line free. Cloning allows you to work on your files locally. If you don't yet have SourceTree, [download and install first](https://www.sourcetreeapp.com/). If you prefer to clone from the command line, see [Clone a repository](https://confluence.atlassian.com/x/4whODQ).

1. You’ll see the clone button under the **Source** heading. Click that button.
2. Now click **Check out in SourceTree**. You may need to create a SourceTree account or log in.
3. When you see the **Clone New** dialog in SourceTree, update the destination path and name if you’d like to and then click **Clone**.
4. Open the directory you just created to see your repository’s files.

Now that you're more familiar with your Bitbucket repository, go ahead and add a new file locally. You can [push your change back to Bitbucket with SourceTree](https://confluence.atlassian.com/x/iqyBMg), or you can [add, commit,](https://confluence.atlassian.com/x/8QhODQ) and [push from the command line](https://confluence.atlassian.com/x/NQ0zDQ).