# Dev Branch

## Purpose
The dev branch is where active development takes place. This is the branch where features are added, bugs are fixed, and new code is written. It is a living branch that is constantly evolving as development work progresses.
Front End HTML webpage templates and CSS static files will be initially pushed to a feature branch. 
Once QA has issued black box and grey box tests that the pages pass, a pull request can be opened for branching code to be merged into dev.

---

# Testing Criteria
Below is a list of requirements for code to satisfy before it can move on from dev:

## Selenium Web Tests
1. Front End code passes all Black Box test cases
2. Front End code passes all Grey Box test cases
3. Test cases cover interactions between items from different branches, as well as than each piece individually

## How to Test
1. Ensure code files to be hosted on the Demand server (URL: https://swe2023team21.xyz) **Consult DevOps**
2. Checkout the tests/Selenium branch, instructions under **Copy code**, replace "dev" with "tests/Selenium" in step 3
3. Open Selenium IDE and open the .side file: Installation instructions can be found on this document: https://docs.google.com/document/d/1m1akPApR7YYkAZjKoTchr6cHnMGQD6SwRv2R7INnwyU/edit?usp=share_link
4. Run all Selenium tests for the Front End, monitor the execution

---
# Features
### Navitgation Bar Template
- Contains the HTML and CSS files required to add the demand user navigation bar to common services pages
### Webskeleton
- Contains all the HTML and CSS files that make up the front end of the TaaS Platform web app, such as a home page, login page, create account page, user dashboard, and more
### Selenium Black & Grey Box Test Cases
- Contains a singular .side file with Black box and Grey box test suites populated with corresponding test cases

---

# Usage
To use the dev branch, clone the repository and switch to the dev branch using the following commands:

## Copy code
1. git clone [repository URL]
2. cd [repository name]
3. git checkout dev
4. From there, you can work on the project, make changes, and push commits to the dev branch. However, it's important to note that code on the dev branch may be in an unstable or unfinished state, so use it at your own risk.

## Merging into Dev
Before merging code into the dev branch, create a feature branch and open a pull request so that other team members can review the changes.
You must be passing all tests sent to you by the QA before pushing to the dev branch.
Please avoid pushing directly to the dev branch unless you have a very good reason to do so.
The dev branch is often used as the basis for creating release branches or tags, so it's important to keep it in good shape.

---

## Contributors
- Kayla Harris (Front End Developer)
- Anne Cuzeau (Login validation for user information)
- Jason Klipple (Initial Repository Setup)
- Jacob Dominguez (QA Black & Grey box tester)
