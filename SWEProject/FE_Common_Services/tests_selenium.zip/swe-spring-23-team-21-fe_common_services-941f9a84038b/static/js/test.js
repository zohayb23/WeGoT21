const express = require('express');
const mysql = require('mysql');

const app = express();

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'mydatabase'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('MySQL connected...');

  // set up routes here
  app.get('/items', (req, res) => {
    connection.query('SELECT * FROM items', (err, rows) => {
      if (err) throw err;
      res.send(rows);
    });
  });

  app.listen(3000, () => console.log('Server started on port 3000'));
});

document.ready(() => {
    $.ajax({
      url: '/items',
      type: 'GET',
      dataType: 'json',
      success: (items) => {
        let itemsHTML = '';
        for (let i = 0; i < items.length; i++) {
          itemsHTML += `<p>${items[i].name} - ${items[i].email}</p>`;
        }
        $('#items-container').html(itemsHTML);
      },
      error: (err) => {
        console.log(err);
      }
    });
  });
  